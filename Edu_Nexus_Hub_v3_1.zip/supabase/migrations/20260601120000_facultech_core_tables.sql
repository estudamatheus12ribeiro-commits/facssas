-- ============================================================================
-- FACULTECH EDUCACIONAL — tabelas centrais (alunos, cursos, matrículas,
-- professores, polos) + RLS + dados iniciais.
-- Rode no Supabase em SQL Editor (ou via CLI). Idempotente o suficiente
-- para um primeiro deploy; os INSERTs usam ON CONFLICT DO NOTHING.
-- ============================================================================

-- ---------- POLOS ----------
CREATE TABLE IF NOT EXISTS public.polos (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        TEXT UNIQUE NOT NULL,
  nome        TEXT NOT NULL,
  cidade      TEXT,
  alunos      INTEGER NOT NULL DEFAULT 0,
  receita     TEXT,
  comissao    TEXT,
  status      TEXT NOT NULL DEFAULT 'Ativo',
  responsavel TEXT,
  abertura    TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- CURSOS ----------
CREATE TABLE IF NOT EXISTS public.cursos (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        TEXT UNIQUE NOT NULL,
  titulo      TEXT NOT NULL,
  modalidade  TEXT,
  carga       TEXT,
  alunos      INTEGER NOT NULL DEFAULT 0,
  disciplinas INTEGER NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'Ativo',
  duracao     TEXT,
  coordenador TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- PROFESSORES ----------
CREATE TABLE IF NOT EXISTS public.professores (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        TEXT UNIQUE NOT NULL,
  nome        TEXT NOT NULL,
  titulacao   TEXT,
  area        TEXT,
  disciplinas INTEGER NOT NULL DEFAULT 0,
  nota        NUMERIC(2,1),
  email       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- ALUNOS ----------
CREATE TABLE IF NOT EXISTS public.alunos (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ra         TEXT UNIQUE NOT NULL,
  nome       TEXT NOT NULL,
  curso      TEXT,
  polo       TEXT,
  status     TEXT NOT NULL DEFAULT 'Ativo',
  progresso  INTEGER NOT NULL DEFAULT 0,
  email      TEXT,
  telefone   TEXT,
  ingresso   TEXT,
  cpf        TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- MATRICULAS ----------
CREATE TABLE IF NOT EXISTS public.matriculas (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  proto       TEXT UNIQUE NOT NULL,
  aluno       TEXT NOT NULL,
  curso       TEXT,
  data        TEXT,
  etapa       TEXT,
  status      TEXT,
  responsavel TEXT,
  valor       TEXT,
  parcelas    TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- RLS: estas são tabelas operacionais da equipe da instituição. Qualquer
-- usuário autenticado (staff) pode ler e gerenciar. Visitantes anônimos não
-- têm acesso. Para multi-instituição no futuro, adicione uma coluna
-- institution_id e restrinja por ela.
-- ============================================================================
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['polos','cursos','professores','alunos','matriculas'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated;', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role;', t);

    EXECUTE format($p$CREATE POLICY "auth read %1$s"   ON public.%1$I FOR SELECT TO authenticated USING (true);$p$, t);
    EXECUTE format($p$CREATE POLICY "auth insert %1$s" ON public.%1$I FOR INSERT TO authenticated WITH CHECK (true);$p$, t);
    EXECUTE format($p$CREATE POLICY "auth update %1$s" ON public.%1$I FOR UPDATE TO authenticated USING (true) WITH CHECK (true);$p$, t);
    EXECUTE format($p$CREATE POLICY "auth delete %1$s" ON public.%1$I FOR DELETE TO authenticated USING (true);$p$, t);
  END LOOP;
END $$;

-- ============================================================================
-- DADOS INICIAIS
-- ============================================================================
-- POLOS
INSERT INTO public.polos (slug, nome, cidade, alunos, receita, comissao, status, responsavel, abertura) VALUES ('polo-sao-paulo-centro', 'Polo São Paulo Centro', 'São Paulo - SP', 1248, 'R$ 612k', 'R$ 48,9k', 'Ativo', 'Roberta Magalhães', '2021') ON CONFLICT DO NOTHING;
INSERT INTO public.polos (slug, nome, cidade, alunos, receita, comissao, status, responsavel, abertura) VALUES ('polo-belo-horizonte', 'Polo Belo Horizonte', 'Belo Horizonte - MG', 847, 'R$ 421k', 'R$ 33,6k', 'Ativo', 'Tiago Santiago', '2022') ON CONFLICT DO NOTHING;
INSERT INTO public.polos (slug, nome, cidade, alunos, receita, comissao, status, responsavel, abertura) VALUES ('polo-curitiba-sul', 'Polo Curitiba Sul', 'Curitiba - PR', 612, 'R$ 304k', 'R$ 24,3k', 'Ativo', 'Luana Prado', '2022') ON CONFLICT DO NOTHING;
INSERT INTO public.polos (slug, nome, cidade, alunos, receita, comissao, status, responsavel, abertura) VALUES ('polo-recife', 'Polo Recife', 'Recife - PE', 489, 'R$ 241k', 'R$ 19,2k', 'Em onboarding', 'Vinícius Borges', '2026') ON CONFLICT DO NOTHING;
INSERT INTO public.polos (slug, nome, cidade, alunos, receita, comissao, status, responsavel, abertura) VALUES ('polo-manaus', 'Polo Manaus', 'Manaus - AM', 312, 'R$ 156k', 'R$ 12,4k', 'Ativo', 'Sabrina Cunha', '2023') ON CONFLICT DO NOTHING;
INSERT INTO public.polos (slug, nome, cidade, alunos, receita, comissao, status, responsavel, abertura) VALUES ('polo-goiania', 'Polo Goiânia', 'Goiânia - GO', 421, 'R$ 208k', 'R$ 16,6k', 'Ativo', 'Roberta Magalhães', '2023') ON CONFLICT DO NOTHING;

-- CURSOS
INSERT INTO public.cursos (slug, titulo, modalidade, carga, alunos, disciplinas, status, duracao, coordenador) VALUES ('mba-gestao-educacional', 'MBA Gestão Educacional', 'Pós-Graduação', '420h', 1248, 12, 'Ativo', '18 meses', 'Dra. Mariana Souza') ON CONFLICT DO NOTHING;
INSERT INTO public.cursos (slug, titulo, modalidade, carga, alunos, disciplinas, status, duracao, coordenador) VALUES ('pedagogia-ead', 'Pedagogia EAD', 'Graduação', '3.200h', 2104, 42, 'Ativo', '48 meses', 'Dra. Helena Castro') ON CONFLICT DO NOTHING;
INSERT INTO public.cursos (slug, titulo, modalidade, carga, alunos, disciplinas, status, duracao, coordenador) VALUES ('engenharia-de-software', 'Engenharia de Software', 'Tecnólogo', '2.400h', 1567, 36, 'Ativo', '36 meses', 'Prof. Rafael Tavares') ON CONFLICT DO NOTHING;
INSERT INTO public.cursos (slug, titulo, modalidade, carga, alunos, disciplinas, status, duracao, coordenador) VALUES ('segunda-licenciatura-em-historia', 'Segunda Licenciatura em História', 'Formação', '1.200h', 512, 18, 'Ativo', '12 meses', 'Prof. Carlos Mendes') ON CONFLICT DO NOTHING;
INSERT INTO public.cursos (slug, titulo, modalidade, carga, alunos, disciplinas, status, duracao, coordenador) VALUES ('eja-ensino-medio', 'EJA - Ensino Médio', 'EJA', '1.600h', 834, 12, 'Ativo', '18 meses', 'Dra. Mariana Souza') ON CONFLICT DO NOTHING;
INSERT INTO public.cursos (slug, titulo, modalidade, carga, alunos, disciplinas, status, duracao, coordenador) VALUES ('excel-avancado-para-gestores', 'Excel Avançado para Gestores', 'Capacitação', '40h', 421, 6, 'Rascunho', '1 mês', 'Prof. André Costa') ON CONFLICT DO NOTHING;

-- PROFESSORES
INSERT INTO public.professores (slug, nome, titulacao, area, disciplinas, nota, email) VALUES ('dra-helena-castro', 'Dra. Helena Castro', 'Doutora', 'Educação', 4, 4.9, 'helena.castro@facultech.edu') ON CONFLICT DO NOTHING;
INSERT INTO public.professores (slug, nome, titulacao, area, disciplinas, nota, email) VALUES ('prof-rafael-tavares', 'Prof. Rafael Tavares', 'Mestre', 'Tecnologia', 6, 4.7, 'rafael.tavares@facultech.edu') ON CONFLICT DO NOTHING;
INSERT INTO public.professores (slug, nome, titulacao, area, disciplinas, nota, email) VALUES ('dra-patricia-lima', 'Dra. Patrícia Lima', 'Doutora', 'Psicopedagogia', 3, 4.8, 'patricia.lima@facultech.edu') ON CONFLICT DO NOTHING;
INSERT INTO public.professores (slug, nome, titulacao, area, disciplinas, nota, email) VALUES ('prof-carlos-mendes', 'Prof. Carlos Mendes', 'Especialista', 'Gestão', 5, 4.6, 'carlos.mendes@facultech.edu') ON CONFLICT DO NOTHING;
INSERT INTO public.professores (slug, nome, titulacao, area, disciplinas, nota, email) VALUES ('dra-mariana-souza', 'Dra. Mariana Souza', 'Doutora', 'Pedagogia', 7, 4.9, 'mariana.souza@facultech.edu') ON CONFLICT DO NOTHING;
INSERT INTO public.professores (slug, nome, titulacao, area, disciplinas, nota, email) VALUES ('prof-andre-costa', 'Prof. André Costa', 'Mestre', 'Matemática', 4, 4.5, 'andre.costa@facultech.edu') ON CONFLICT DO NOTHING;

-- ALUNOS
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024001', 'Ana Beatriz Lima', 'Pedagogia EAD', 'São Paulo - SP', 'Ativo', 78, 'ana.lima@email.com', '(11) 98421-7732', 'Fev/2024', '412.998.221-04') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024002', 'Bruno Carvalho', 'MBA Gestão Educacional', 'Belo Horizonte - MG', 'Ativo', 45, 'bruno.carvalho@email.com', '(31) 99812-4421', 'Ago/2024', '327.118.094-21') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024003', 'Camila Duarte', 'Pós Psicopedagogia', 'Curitiba - PR', 'Ativo', 92, 'camila.duarte@email.com', '(41) 99110-8843', 'Jan/2024', '554.221.873-90') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024004', 'Diego Ferreira', 'Engenharia Software', 'Recife - PE', 'Inadimplente', 34, 'diego.f@email.com', '(81) 98112-7711', 'Mar/2024', '881.443.221-08') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024005', 'Eduarda Martins', 'Segunda Licenciatura', 'Fortaleza - CE', 'Ativo', 67, 'eduarda.m@email.com', '(85) 99421-3320', 'Jul/2024', '112.665.443-22') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024006', 'Felipe Nascimento', 'EJA - Médio', 'Salvador - BA', 'Trancado', 12, 'felipe.n@email.com', '(71) 98765-4321', 'Set/2023', '443.998.112-66') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024007', 'Gabriela Rocha', 'Tecnólogo em Marketing', 'Porto Alegre - RS', 'Ativo', 88, 'gabriela.r@email.com', '(51) 99887-6543', 'Fev/2024', '776.554.332-11') ON CONFLICT DO NOTHING;
INSERT INTO public.alunos (ra, nome, curso, polo, status, progresso, email, telefone, ingresso, cpf) VALUES ('2024008', 'Henrique Sales', 'Formação Pedagógica', 'São Paulo - SP', 'Ativo', 23, 'henrique.s@email.com', '(11) 99443-2210', 'Mai/2024', '998.776.554-43') ON CONFLICT DO NOTHING;

-- MATRICULAS
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042189', 'Larissa Oliveira', 'MBA Gestão Educacional', '29/05/2026', 'Contrato', 'Aguardando assinatura', 'Roberta Magalhães', 'R$ 8.400,00', '18x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042190', 'Marcos Vinícius', 'Pedagogia EAD', '30/05/2026', 'Documentos', 'Em análise', 'Tiago Santiago', 'R$ 12.600,00', '48x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042191', 'Patrícia Gomes', 'Pós Psicopedagogia', '30/05/2026', 'Pagamento', 'Pendente', 'Luana Prado', 'R$ 7.800,00', '12x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042192', 'Ricardo Almeida', 'Engenharia Software', '31/05/2026', 'Concluída', 'Matriculado', 'Vinícius Borges', 'R$ 18.000,00', '36x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042193', 'Fernanda Lopes', 'Tecnólogo em Marketing', '31/05/2026', 'Documentos', 'Aguardando RG', 'Sabrina Cunha', 'R$ 9.200,00', '24x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042194', 'Gustavo Henrique', 'Segunda Licenciatura História', '31/05/2026', 'Contrato', 'Enviado p/ assinatura', 'Roberta Magalhães', 'R$ 6.800,00', '12x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042195', 'Helena Prado', 'Pedagogia EAD', '30/05/2026', 'Pagamento', 'Boleto vencido', 'Tiago Santiago', 'R$ 12.600,00', '48x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042196', 'Igor Bastos', 'MBA Gestão Educacional', '29/05/2026', 'Concluída', 'Matriculado', 'Vinícius Borges', 'R$ 8.400,00', '18x') ON CONFLICT DO NOTHING;
INSERT INTO public.matriculas (proto, aluno, curso, data, etapa, status, responsavel, valor, parcelas) VALUES ('MAT-0042197', 'Juliana Reis', 'EJA - Médio', '28/05/2026', 'Documentos', 'Pendente histórico', 'Luana Prado', 'R$ 2.400,00', '12x') ON CONFLICT DO NOTHING;
