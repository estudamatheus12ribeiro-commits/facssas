// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  // Enable the Nitro deploy plugin on every build (outside the Lovable sandbox
  // it is skipped by default). The preset controls the output target:
  //   - node-server      -> portable Node build in .output/ (Render, Railway, Fly, Docker, VPS)
  //   - cloudflare-module-> Cloudflare Workers (the Lovable default)
  //   - vercel / netlify -> their respective platforms
  // Override at build time with: NITRO_PRESET=cloudflare-module npm run build
  nitro: { preset: process.env.NITRO_PRESET || "node-server" },
});
