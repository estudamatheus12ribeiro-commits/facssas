export const slug = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

export const alunosDemo = [
  { ra: "2024001", nome: "Ana Beatriz Lima", curso: "Pedagogia EAD", polo: "São Paulo - SP", status: "Ativo", progresso: 78, email: "ana.lima@email.com", telefone: "(11) 98421-7732", ingresso: "Fev/2024", cpf: "412.998.221-04" },
  { ra: "2024002", nome: "Bruno Carvalho", curso: "MBA Gestão Educacional", polo: "Belo Horizonte - MG", status: "Ativo", progresso: 45, email: "bruno.carvalho@email.com", telefone: "(31) 99812-4421", ingresso: "Ago/2024", cpf: "327.118.094-21" },
  { ra: "2024003", nome: "Camila Duarte", curso: "Pós Psicopedagogia", polo: "Curitiba - PR", status: "Ativo", progresso: 92, email: "camila.duarte@email.com", telefone: "(41) 99110-8843", ingresso: "Jan/2024", cpf: "554.221.873-90" },
  { ra: "2024004", nome: "Diego Ferreira", curso: "Engenharia Software", polo: "Recife - PE", status: "Inadimplente", progresso: 34, email: "diego.f@email.com", telefone: "(81) 98112-7711", ingresso: "Mar/2024", cpf: "881.443.221-08" },
  { ra: "2024005", nome: "Eduarda Martins", curso: "Segunda Licenciatura", polo: "Fortaleza - CE", status: "Ativo", progresso: 67, email: "eduarda.m@email.com", telefone: "(85) 99421-3320", ingresso: "Jul/2024", cpf: "112.665.443-22" },
  { ra: "2024006", nome: "Felipe Nascimento", curso: "EJA - Médio", polo: "Salvador - BA", status: "Trancado", progresso: 12, email: "felipe.n@email.com", telefone: "(71) 98765-4321", ingresso: "Set/2023", cpf: "443.998.112-66" },
  { ra: "2024007", nome: "Gabriela Rocha", curso: "Tecnólogo em Marketing", polo: "Porto Alegre - RS", status: "Ativo", progresso: 88, email: "gabriela.r@email.com", telefone: "(51) 99887-6543", ingresso: "Fev/2024", cpf: "776.554.332-11" },
  { ra: "2024008", nome: "Henrique Sales", curso: "Formação Pedagógica", polo: "São Paulo - SP", status: "Ativo", progresso: 23, email: "henrique.s@email.com", telefone: "(11) 99443-2210", ingresso: "Mai/2024", cpf: "998.776.554-43" },
] as const;

export const matriculasDemo = [
  { proto: "MAT-0042189", aluno: "Larissa Oliveira", curso: "MBA Gestão Educacional", data: "29/05/2026", etapa: "Contrato", status: "Aguardando assinatura", responsavel: "Roberta Magalhães", valor: "R$ 8.400,00", parcelas: "18x" },
  { proto: "MAT-0042190", aluno: "Marcos Vinícius", curso: "Pedagogia EAD", data: "30/05/2026", etapa: "Documentos", status: "Em análise", responsavel: "Tiago Santiago", valor: "R$ 12.600,00", parcelas: "48x" },
  { proto: "MAT-0042191", aluno: "Patrícia Gomes", curso: "Pós Psicopedagogia", data: "30/05/2026", etapa: "Pagamento", status: "Pendente", responsavel: "Luana Prado", valor: "R$ 7.800,00", parcelas: "12x" },
  { proto: "MAT-0042192", aluno: "Ricardo Almeida", curso: "Engenharia Software", data: "31/05/2026", etapa: "Concluída", status: "Matriculado", responsavel: "Vinícius Borges", valor: "R$ 18.000,00", parcelas: "36x" },
] as const;

export const professoresDemo = [
  { nome: "Dra. Helena Castro", titulacao: "Doutora", area: "Educação", disciplinas: 4, nota: 4.9, email: "helena.castro@facultech.edu" },
  { nome: "Prof. Rafael Tavares", titulacao: "Mestre", area: "Tecnologia", disciplinas: 6, nota: 4.7, email: "rafael.tavares@facultech.edu" },
  { nome: "Dra. Patrícia Lima", titulacao: "Doutora", area: "Psicopedagogia", disciplinas: 3, nota: 4.8, email: "patricia.lima@facultech.edu" },
  { nome: "Prof. Carlos Mendes", titulacao: "Especialista", area: "Gestão", disciplinas: 5, nota: 4.6, email: "carlos.mendes@facultech.edu" },
  { nome: "Dra. Mariana Souza", titulacao: "Doutora", area: "Pedagogia", disciplinas: 7, nota: 4.9, email: "mariana.souza@facultech.edu" },
  { nome: "Prof. André Costa", titulacao: "Mestre", area: "Matemática", disciplinas: 4, nota: 4.5, email: "andre.costa@facultech.edu" },
] as const;

export const cursosDemo = [
  { titulo: "MBA Gestão Educacional", modalidade: "Pós-Graduação", carga: "420h", alunos: 1248, disciplinas: 12, status: "Ativo", duracao: "18 meses", coordenador: "Dra. Mariana Souza" },
  { titulo: "Pedagogia EAD", modalidade: "Graduação", carga: "3.200h", alunos: 2104, disciplinas: 42, status: "Ativo", duracao: "48 meses", coordenador: "Dra. Helena Castro" },
  { titulo: "Engenharia de Software", modalidade: "Tecnólogo", carga: "2.400h", alunos: 1567, disciplinas: 36, status: "Ativo", duracao: "36 meses", coordenador: "Prof. Rafael Tavares" },
  { titulo: "Segunda Licenciatura em História", modalidade: "Formação", carga: "1.200h", alunos: 512, disciplinas: 18, status: "Ativo", duracao: "12 meses", coordenador: "Prof. Carlos Mendes" },
  { titulo: "EJA - Ensino Médio", modalidade: "EJA", carga: "1.600h", alunos: 834, disciplinas: 12, status: "Ativo", duracao: "18 meses", coordenador: "Dra. Mariana Souza" },
  { titulo: "Excel Avançado para Gestores", modalidade: "Capacitação", carga: "40h", alunos: 421, disciplinas: 6, status: "Rascunho", duracao: "1 mês", coordenador: "Prof. André Costa" },
] as const;

export const polosDemo = [
  { nome: "Polo São Paulo Centro", cidade: "São Paulo - SP", alunos: 1248, receita: "R$ 612k", comissao: "R$ 48,9k", status: "Ativo", responsavel: "Roberta Magalhães", abertura: "2021" },
  { nome: "Polo Belo Horizonte", cidade: "Belo Horizonte - MG", alunos: 847, receita: "R$ 421k", comissao: "R$ 33,6k", status: "Ativo", responsavel: "Tiago Santiago", abertura: "2022" },
  { nome: "Polo Curitiba Sul", cidade: "Curitiba - PR", alunos: 612, receita: "R$ 304k", comissao: "R$ 24,3k", status: "Ativo", responsavel: "Luana Prado", abertura: "2022" },
  { nome: "Polo Recife", cidade: "Recife - PE", alunos: 489, receita: "R$ 241k", comissao: "R$ 19,2k", status: "Em onboarding", responsavel: "Vinícius Borges", abertura: "2026" },
  { nome: "Polo Manaus", cidade: "Manaus - AM", alunos: 312, receita: "R$ 156k", comissao: "R$ 12,4k", status: "Ativo", responsavel: "Sabrina Cunha", abertura: "2023" },
  { nome: "Polo Goiânia", cidade: "Goiânia - GO", alunos: 421, receita: "R$ 208k", comissao: "R$ 16,6k", status: "Ativo", responsavel: "Roberta Magalhães", abertura: "2023" },
] as const;