import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

// Tipos das linhas, derivados do schema gerado do Supabase.
export type Aluno = Tables<"alunos">;
export type Curso = Tables<"cursos">;
export type Matricula = Tables<"matriculas">;
export type Professor = Tables<"professores">;
export type Polo = Tables<"polos">;

// Helper: lança o erro do Supabase (capturado pelo React Query) ou devolve os dados.
function unwrap<T>({ data, error }: { data: T | null; error: { message: string } | null }): T {
  if (error) throw new Error(error.message);
  return (data ?? []) as T;
}

// ---------------- ALUNOS ----------------
export function useAlunos() {
  return useQuery({
    queryKey: ["alunos"],
    queryFn: async () =>
      unwrap(await supabase.from("alunos").select("*").order("ra", { ascending: true })),
  });
}

export function useAluno(ra: string) {
  return useQuery({
    queryKey: ["aluno", ra],
    queryFn: async () => {
      const { data, error } = await supabase.from("alunos").select("*").eq("ra", ra).maybeSingle();
      if (error) throw new Error(error.message);
      return data; // null => não encontrado
    },
  });
}

// ---------------- CURSOS ----------------
export function useCursos() {
  return useQuery({
    queryKey: ["cursos"],
    queryFn: async () =>
      unwrap(await supabase.from("cursos").select("*").order("titulo", { ascending: true })),
  });
}

export function useCurso(slug: string) {
  return useQuery({
    queryKey: ["curso", slug],
    queryFn: async () => {
      const { data, error } = await supabase.from("cursos").select("*").eq("slug", slug).maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });
}

// ---------------- MATRICULAS ----------------
export function useMatriculas() {
  return useQuery({
    queryKey: ["matriculas"],
    queryFn: async () =>
      unwrap(await supabase.from("matriculas").select("*").order("proto", { ascending: false })),
  });
}

export function useMatricula(proto: string) {
  return useQuery({
    queryKey: ["matricula", proto],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("matriculas")
        .select("*")
        .eq("proto", proto)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });
}

// ---------------- PROFESSORES ----------------
export function useProfessores() {
  return useQuery({
    queryKey: ["professores"],
    queryFn: async () =>
      unwrap(await supabase.from("professores").select("*").order("nome", { ascending: true })),
  });
}

export function useProfessor(slug: string) {
  return useQuery({
    queryKey: ["professor", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("professores")
        .select("*")
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });
}

// ---------------- POLOS ----------------
export function usePolos() {
  return useQuery({
    queryKey: ["polos"],
    queryFn: async () =>
      unwrap(await supabase.from("polos").select("*").order("nome", { ascending: true })),
  });
}

export function usePolo(slug: string) {
  return useQuery({
    queryKey: ["polo", slug],
    queryFn: async () => {
      const { data, error } = await supabase.from("polos").select("*").eq("slug", slug).maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });
}
