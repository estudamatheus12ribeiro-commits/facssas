import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";
import { ArrowLeft, Loader2 } from "lucide-react";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — FACULTECH EDUCACIONAL" },
      { name: "description", content: "Acesse sua conta FACULTECH para gerir alunos, cursos e operações." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) navigate({ to: "/dashboard", replace: true });
  }, [user, navigate]);

  async function handleEmailLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Bem-vindo de volta!");
    navigate({ to: "/dashboard", replace: true });
  }

  async function handleGoogle() {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) toast.error("Não foi possível entrar com Google");
  }

  return <AuthShell mode="login" loading={loading} email={email} setEmail={setEmail} password={password} setPassword={setPassword} onSubmit={handleEmailLogin} onGoogle={handleGoogle} />;
}

export function AuthShell(props: {
  mode: "login" | "signup";
  loading: boolean;
  email: string; setEmail: (v: string) => void;
  password: string; setPassword: (v: string) => void;
  fullName?: string; setFullName?: (v: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  onGoogle: () => void;
}) {
  const isSignup = props.mode === "signup";
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Brand panel */}
      <div
        className="relative hidden flex-col justify-between overflow-hidden p-12 lg:flex"
        style={{ backgroundImage: "var(--gradient-hero)" }}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,oklch(0.65_0.22_258/0.4),transparent_60%)]" />
        <div className="relative">
          <Link to="/" className="text-white"><Logo /></Link>
        </div>
        <div className="relative text-white">
          <h2 className="font-display text-4xl font-bold leading-tight">
            A gestão acadêmica da sua instituição, em um único lugar.
          </h2>
          <p className="mt-4 max-w-md text-white/70">
            Multi-instituição, multi-polo, com CRM, AVA, financeiro e IA — pronto para escalar.
          </p>
        </div>
        <div className="relative text-xs text-white/60">© {new Date().getFullYear()} FACULTECH EDUCACIONAL</div>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center bg-background p-6 lg:p-12">
        <div className="w-full max-w-md">
          <Link to="/" className="mb-8 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Voltar para o site
          </Link>
          <div className="lg:hidden mb-8"><Logo /></div>

          <h1 className="text-3xl font-bold">{isSignup ? "Criar sua conta" : "Bem-vindo de volta"}</h1>
          <p className="mt-2 text-muted-foreground">
            {isSignup ? "Comece a operar sua instituição em minutos." : "Entre para acessar seu painel."}
          </p>

          <Button onClick={props.onGoogle} variant="outline" className="mt-8 w-full">
            <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continuar com Google
          </Button>

          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs uppercase tracking-wider text-muted-foreground">ou com e-mail</span>
            <div className="h-px flex-1 bg-border" />
          </div>

          <form onSubmit={props.onSubmit} className="space-y-4">
            {isSignup && props.setFullName && (
              <div>
                <Label htmlFor="name">Nome completo</Label>
                <Input id="name" value={props.fullName} onChange={(e) => props.setFullName!(e.target.value)} required maxLength={120} className="mt-1.5" />
              </div>
            )}
            <div>
              <Label htmlFor="email">E-mail</Label>
              <Input id="email" type="email" value={props.email} onChange={(e) => props.setEmail(e.target.value)} required className="mt-1.5" />
            </div>
            <div>
              <Label htmlFor="password">Senha</Label>
              <Input id="password" type="password" value={props.password} onChange={(e) => props.setPassword(e.target.value)} required minLength={6} className="mt-1.5" />
            </div>
            <Button type="submit" variant="hero" className="w-full" disabled={props.loading}>
              {props.loading && <Loader2 className="h-4 w-4 animate-spin" />}
              {isSignup ? "Criar conta" : "Entrar"}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {isSignup ? (
              <>Já tem uma conta? <Link to="/login" className="font-medium text-primary hover:underline">Entrar</Link></>
            ) : (
              <>Ainda não tem conta? <Link to="/signup" className="font-medium text-primary hover:underline">Criar conta</Link></>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}