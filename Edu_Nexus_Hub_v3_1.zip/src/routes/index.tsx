import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Users,
  GraduationCap,
  BookOpen,
  Wallet,
  BarChart3,
  Award,
  MessagesSquare,
  Building2,
  Sparkles,
  ShieldCheck,
  Layers,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import heroImg from "@/assets/hero-facultech.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FACULTECH EDUCACIONAL — Plataforma SaaS completa para instituições de ensino" },
      { name: "description", content: "CRM, AVA, matrículas, financeiro, certificação e BI para faculdades, polos EAD e cursos técnicos. Multi-tenant, escalável, com IA nativa." },
      { property: "og:title", content: "FACULTECH EDUCACIONAL" },
      { property: "og:description", content: "A plataforma educacional corporativa, multi-instituição e multi-polo." },
    ],
  }),
  component: Landing,
});

const modules = [
  { icon: MessagesSquare, title: "CRM Educacional", desc: "Pipeline Lead → Aluno com WhatsApp, e-mail marketing e automações." },
  { icon: GraduationCap, title: "Matrículas Digitais", desc: "Inscrição, análise documental, contrato e assinatura digital." },
  { icon: BookOpen, title: "AVA Completo", desc: "Videoaulas, PDFs, fóruns, simulados e controle de progresso." },
  { icon: Wallet, title: "Financeiro", desc: "PIX, boleto e cartão com Asaas, Mercado Pago e Stripe. DRE em tempo real." },
  { icon: Award, title: "Certificação Digital", desc: "Diplomas e certificados com QR Code e validação pública online." },
  { icon: Building2, title: "Gestão de Polos", desc: "Polos parceiros, convênios e comissões automáticas por venda." },
  { icon: BarChart3, title: "BI Executivo", desc: "Dashboards com matrículas, receita, evasão, ticket médio e conversão." },
  { icon: Sparkles, title: "IA Educacional", desc: "Crie planos de ensino, provas, comunicados e corrija redações em segundos." },
];

const courseTypes = [
  "Graduação", "Pós-Graduação", "Tecnólogos", "Cursos Técnicos",
  "Cursos Livres", "EJA", "Formação Pedagógica", "Segunda Licenciatura",
  "Capacitações Corporativas", "Polos EAD", "Centros Universitários", "Institutos de Educação",
];

const differentiators = [
  "CRM comercial nativo (não é integração)",
  "Aproveitamento curricular automatizado",
  "Certificação por competência (CTPS + contratos)",
  "WhatsApp e disparo em massa integrados",
  "Multi-tenant com isolamento por instituição",
  "Pronto para 10.000+ alunos simultâneos",
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      <CourseStrip />
      <ModulesSection />
      <DifferentiatorSection />
      <CTASection />
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex">
          <a href="#modulos" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Módulos</a>
          <a href="#publico" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Público</a>
          <a href="#diferenciais" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Diferenciais</a>
        </nav>
        <div className="flex items-center gap-3">
          <Button asChild variant="ghost" size="sm">
            <Link to="/login">Entrar</Link>
          </Button>
          <Button asChild variant="hero" size="sm">
            <Link to="/signup">Começar agora <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div
        className="absolute inset-0 -z-10"
        style={{
          backgroundImage: `linear-gradient(135deg, oklch(0.18 0.08 265 / 0.95), oklch(0.28 0.12 263 / 0.88), oklch(0.42 0.18 260 / 0.75)), url(${heroImg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_70%_30%,oklch(0.65_0.22_258/0.35),transparent_60%)]" />

      <div className="mx-auto max-w-7xl px-6 py-24 md:py-36">
        <div className="max-w-3xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-4 py-1.5 text-xs font-medium text-white/90 backdrop-blur">
            <Sparkles className="h-3.5 w-3.5" />
            Plataforma SaaS Multi-Instituição com IA nativa
          </div>
          <h1 className="text-5xl font-bold leading-[1.05] text-white md:text-7xl">
            A plataforma educacional <span className="bg-gradient-to-r from-[oklch(0.85_0.15_258)] to-white bg-clip-text text-transparent">corporativa</span> da nova geração.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/75 md:text-xl">
            FACULTECH centraliza gestão acadêmica, CRM, AVA, financeiro e certificação em um único sistema. Pensado para faculdades, polos EAD, cursos técnicos e capacitações corporativas.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Button asChild size="lg" variant="hero">
              <Link to="/signup">Criar minha conta <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <Button asChild size="lg" variant="glass">
              <Link to="/login">Já sou cliente</Link>
            </Button>
          </div>
          <div className="mt-12 grid max-w-2xl grid-cols-3 gap-6 border-t border-white/10 pt-8">
            <Stat value="10k+" label="Alunos simultâneos" />
            <Stat value="13" label="Modalidades de curso" />
            <Stat value="100%" label="Multi-tenant nativo" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <div className="font-display text-3xl font-bold text-white">{value}</div>
      <div className="mt-1 text-xs uppercase tracking-wider text-white/60">{label}</div>
    </div>
  );
}

function CourseStrip() {
  return (
    <section id="publico" className="border-y border-border bg-secondary/40 py-10">
      <div className="mx-auto max-w-7xl px-6">
        <p className="mb-6 text-center text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Para todas as modalidades de ensino
        </p>
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-3">
          {courseTypes.map((c) => (
            <span key={c} className="rounded-full border border-border bg-card px-4 py-1.5 text-sm font-medium text-foreground/80 shadow-sm">
              {c}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

function ModulesSection() {
  return (
    <section id="modulos" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            <Layers className="h-3.5 w-3.5" /> Módulos integrados
          </div>
          <h2 className="mt-4 text-4xl font-bold leading-tight md:text-5xl">
            Um sistema. Toda a operação.
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Substitui Lyceum, TOTVS, Sponte, Moodle e Blackboard — com CRM, comissões e IA nativos.
          </p>
        </div>

        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {modules.map((m) => (
            <div
              key={m.title}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 hover:border-primary/30 hover:shadow-[var(--shadow-elegant)]"
            >
              <div className="mb-5 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-glow)]">
                <m.icon className="h-5 w-5" />
              </div>
              <h3 className="mb-2 text-base font-semibold">{m.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{m.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function DifferentiatorSection() {
  return (
    <section id="diferenciais" className="bg-secondary/40 py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-16 px-6 lg:grid-cols-2">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            <ShieldCheck className="h-3.5 w-3.5" /> O diferencial FACULTECH
          </div>
          <h2 className="mt-4 text-4xl font-bold leading-tight md:text-5xl">
            Superior aos sistemas tradicionais do mercado.
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Construído para escalar de 100 a 10.000+ alunos, com isolamento de dados por instituição e automações inteligentes que crescem com você.
          </p>
        </div>

        <ul className="space-y-4">
          {differentiators.map((d) => (
            <li key={d} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
              <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
              <span className="text-base font-medium text-foreground">{d}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-5xl px-6">
        <div
          className="relative overflow-hidden rounded-3xl p-12 text-center shadow-[var(--shadow-elegant)] md:p-16"
          style={{ backgroundImage: "var(--gradient-hero)" }}
        >
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,oklch(0.65_0.22_258/0.5),transparent_70%)]" />
          <div className="relative">
            <Users className="mx-auto h-12 w-12 text-white/80" />
            <h2 className="mt-6 text-4xl font-bold leading-tight text-white md:text-5xl">
              Pronto para digitalizar sua instituição?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-lg text-white/75">
              Crie sua conta e tenha acesso ao ambiente do aluno. Onboarding completo da instituição em até 7 dias.
            </p>
            <Button asChild size="lg" variant="hero" className="mt-8">
              <Link to="/signup">Começar gratuitamente <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 md:flex-row">
        <Logo />
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} FACULTECH EDUCACIONAL. Plataforma SaaS multi-instituição.
        </p>
      </div>
    </footer>
  );
}
