import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  FileText, Inbox, Clock, CheckCircle2, AlertTriangle, Plus,
  Search, Filter, MessageSquare, Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/secretaria")({
  head: () => ({ meta: [{ title: "Secretaria & Protocolos — FACULTECH" }] }),
  component: Secretaria,
});

const protocolos = [
  { num: "PRT-2026-08741", tipo: "Histórico escolar", aluno: "Ana Beatriz Lima", abertura: "29/05/2026", sla: "2d", responsavel: "Roberta Magalhães", status: "Em emissão" },
  { num: "PRT-2026-08742", tipo: "Declaração de matrícula", aluno: "Bruno Carvalho", abertura: "30/05/2026", sla: "1d", responsavel: "Tiago Santiago", status: "Concluído" },
  { num: "PRT-2026-08743", tipo: "Revisão de nota", aluno: "Diego Ferreira", abertura: "28/05/2026", sla: "5d", responsavel: "Luana Prado", status: "Em análise" },
  { num: "PRT-2026-08744", tipo: "Trancamento", aluno: "Felipe Nascimento", abertura: "27/05/2026", sla: "3d", responsavel: "Vinícius Borges", status: "Aguardando aluno" },
  { num: "PRT-2026-08745", tipo: "Segunda via diploma", aluno: "Camila Duarte", abertura: "26/05/2026", sla: "10d", responsavel: "Sabrina Cunha", status: "MEC" },
  { num: "PRT-2026-08746", tipo: "Reabertura matrícula", aluno: "Gustavo Henrique", abertura: "31/05/2026", sla: "2d", responsavel: "Roberta Magalhães", status: "Vencido" },
] as const;

const tipos = [
  { titulo: "Histórico", count: 142, icon: FileText },
  { titulo: "Declarações", count: 218, icon: FileText },
  { titulo: "Revisões", count: 34, icon: Inbox },
  { titulo: "Trancamento", count: 19, icon: AlertTriangle },
] as const;

const filtros = ["Todos", "Abertos", "Em análise", "Concluídos", "Vencidos"] as const;

const badge = (s: string) => {
  const t = s.toLowerCase();
  if (t.includes("conclu")) return "bg-emerald-100 text-emerald-700";
  if (t.includes("vencid")) return "bg-rose-100 text-rose-700";
  if (t.includes("aguard") || t.includes("anál") || t.includes("mec")) return "bg-amber-100 text-amber-700";
  return "bg-blue-100 text-blue-700";
};

function Secretaria() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Secretaria acadêmica & Protocolos"
        description="Atendimento ao aluno, abertura de protocolos, emissão de documentos e SLA de resposta."
        actions={
          <>
            <Button variant="outline" size="sm"><MessageSquare className="h-4 w-4" /> Atendimentos</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Abrir protocolo</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Protocolos abertos (mês)" value="613" icon={Inbox} accent="text-blue-600" />
          <StatCard label="Resolvidos no SLA" value="92%" icon={CheckCircle2} accent="text-emerald-600" />
          <StatCard label="Tempo médio" value="1,8 dias" icon={Clock} accent="text-violet-600" />
          <StatCard label="Vencidos" value="14" icon={AlertTriangle} accent="text-rose-600" />
        </section>

        <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {tipos.map((t) => (
            <div key={t.titulo} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">{t.titulo}</p>
                <t.icon className="h-4 w-4 text-primary" />
              </div>
              <p className="mt-3 font-display text-2xl font-bold">{t.count}</p>
              <p className="text-xs text-muted-foreground">protocolos no mês</p>
            </div>
          ))}
        </section>

        <section className="flex items-start gap-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
          <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
          <div className="flex-1 text-sm">
            <p className="font-semibold">Atendente IA resolveu 73% dos chamados sem intervenção humana</p>
            <p className="text-muted-foreground">Respostas automáticas via WhatsApp + portal do aluno com base no regimento institucional.</p>
          </div>
          <Button variant="outline" size="sm">Configurar IA</Button>
        </section>

        <section className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-2">
            {filtros.map((f, i) => (
              <button
                key={f}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${i === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                placeholder="Buscar protocolo ou aluno..."
                className="h-9 w-72 rounded-lg border border-border bg-background pl-8 pr-3 text-xs outline-none focus:border-primary"
              />
            </div>
            <Button variant="outline" size="sm"><Filter className="h-4 w-4" /> Filtros</Button>
          </div>
        </section>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Protocolo</th>
                <th className="px-4 py-3">Tipo</th>
                <th className="px-4 py-3">Aluno</th>
                <th className="px-4 py-3">Abertura</th>
                <th className="px-4 py-3">SLA</th>
                <th className="px-4 py-3">Responsável</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {protocolos.map((p) => (
                <tr key={p.num} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-mono text-xs">{p.num}</td>
                  <td className="px-4 py-3 font-medium">{p.tipo}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.aluno}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.abertura}</td>
                  <td className="px-4 py-3"><span className="rounded bg-secondary px-2 py-0.5 font-mono text-xs">{p.sla}</span></td>
                  <td className="px-4 py-3 text-muted-foreground">{p.responsavel}</td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${badge(p.status)}`}>{p.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}