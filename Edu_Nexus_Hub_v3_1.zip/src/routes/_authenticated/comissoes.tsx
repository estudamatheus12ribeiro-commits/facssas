import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Receipt, TrendingUp, Wallet, Users, Download } from "lucide-react";

export const Route = createFileRoute("/_authenticated/comissoes")({
  head: () => ({ meta: [{ title: "Comissões — FACULTECH" }] }),
  component: Comissoes,
});

const consultores = [
  { nome: "Roberta Magalhães", polo: "São Paulo", matriculas: 84, comissao: "R$ 18.420", status: "A pagar" },
  { nome: "Tiago Santiago", polo: "BH", matriculas: 62, comissao: "R$ 13.640", status: "A pagar" },
  { nome: "Luana Prado", polo: "Curitiba", matriculas: 51, comissao: "R$ 11.220", status: "Pago" },
  { nome: "Vinícius Borges", polo: "Recife", matriculas: 47, comissao: "R$ 10.340", status: "A pagar" },
  { nome: "Sabrina Cunha", polo: "Fortaleza", matriculas: 41, comissao: "R$ 9.020", status: "Pago" },
];

const statusColor: Record<string, string> = {
  "A pagar": "bg-amber-500/10 text-amber-700",
  Pago: "bg-emerald-500/10 text-emerald-700",
};

function Comissoes() {
  return (
    <>
      <PageHeader
        eyebrow="Comercial"
        title="Comissões e repasses"
        description="Cálculo automático sobre matrículas confirmadas. Repasses para consultores, polos e parceiros."
        actions={<Button variant="hero" size="sm"><Download className="h-4 w-4" /> Gerar repasse</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="A pagar (mês)" value="R$ 312k" icon={Wallet} accent="text-amber-600" />
          <StatCard label="Pagos no mês" value="R$ 248k" icon={Receipt} accent="text-emerald-600" />
          <StatCard label="Consultores ativos" value="124" icon={Users} accent="text-blue-600" />
          <StatCard label="Ticket médio comissão" value="R$ 218" hint="por matrícula" icon={TrendingUp} accent="text-violet-600" />
        </section>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <div className="border-b border-border p-4"><h2 className="font-display text-lg font-semibold">Top consultores — Maio/2026</h2></div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr><th className="px-4 py-3">Consultor</th><th className="px-4 py-3">Polo</th><th className="px-4 py-3">Matrículas</th><th className="px-4 py-3">Comissão</th><th className="px-4 py-3">Status</th><th></th></tr>
            </thead>
            <tbody>
              {consultores.map((c) => (
                <tr key={c.nome} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-medium">{c.nome}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.polo}</td>
                  <td className="px-4 py-3">{c.matriculas}</td>
                  <td className="px-4 py-3 font-mono font-semibold">{c.comissao}</td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusColor[c.status]}`}>{c.status}</span></td>
                  <td className="px-4 py-3 text-right"><Button variant="ghost" size="sm">Extrato</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}