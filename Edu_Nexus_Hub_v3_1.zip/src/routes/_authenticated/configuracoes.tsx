import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Building2, Users, Shield, Plug, CreditCard, Bell } from "lucide-react";

export const Route = createFileRoute("/_authenticated/configuracoes")({
  head: () => ({ meta: [{ title: "Configurações — FACULTECH" }] }),
  component: Configuracoes,
});

const grupos = [
  { titulo: "Instituição", desc: "Razão social, CNPJ, identidade visual, domínios.", icon: Building2 },
  { titulo: "Usuários e papéis", desc: "Admin, coordenador, professor, secretaria, aluno.", icon: Users },
  { titulo: "Segurança", desc: "MFA, SSO/SAML, política de senhas, auditoria.", icon: Shield },
  { titulo: "Integrações", desc: "WhatsApp, Asaas, Stripe, Moodle, Microsoft, Google.", icon: Plug },
  { titulo: "Faturamento", desc: "Plano FACULTECH, consumo de IA, faturas.", icon: CreditCard },
  { titulo: "Notificações", desc: "E-mail, push, WhatsApp e webhook por evento.", icon: Bell },
];

function Configuracoes() {
  return (
    <>
      <PageHeader
        eyebrow="Operação"
        title="Configurações da instituição"
        description="Multi-tenant, papéis, integrações e regras globais da plataforma."
      />
      <div className="grid gap-4 p-6 md:grid-cols-2 lg:p-10 xl:grid-cols-3">
        {grupos.map((g) => (
          <article key={g.titulo} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <g.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold">{g.titulo}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{g.desc}</p>
            <Button variant="outline" size="sm" className="mt-4 w-full">Abrir</Button>
          </article>
        ))}
      </div>
    </>
  );
}