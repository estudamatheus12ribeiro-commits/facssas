import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Briefcase, Phone, Mail, MessageCircle, Plus, Filter, TrendingUp, Target, Users } from "lucide-react";

export const Route = createFileRoute("/_authenticated/crm")({
  head: () => ({ meta: [{ title: "CRM — FACULTECH" }] }),
  component: CRM,
});

type Lead = { name: string; course: string; origin: string; score: number; phone: string };
const stages: { id: string; label: string; color: string; leads: Lead[] }[] = [
  { id: "novo", label: "Novo Lead", color: "bg-slate-500", leads: [
    { name: "Mariana Souza", course: "MBA Gestão Educacional", origin: "Instagram", score: 72, phone: "(11) 9 8845-2210" },
    { name: "Carlos Eduardo Lima", course: "Pedagogia EAD", origin: "Google Ads", score: 65, phone: "(31) 9 8120-7733" },
    { name: "Rafael Mendes", course: "Engenharia Software", origin: "Indicação", score: 81, phone: "(21) 9 9410-2200" },
  ]},
  { id: "qualif", label: "Qualificado", color: "bg-blue-500", leads: [
    { name: "Juliana Reis", course: "Pós Psicopedagogia", origin: "WhatsApp", score: 88, phone: "(11) 9 7702-3315" },
    { name: "André Pinto", course: "EJA Médio", origin: "Site", score: 70, phone: "(85) 9 9018-4422" },
  ]},
  { id: "proposta", label: "Proposta", color: "bg-violet-500", leads: [
    { name: "Fernanda Castro", course: "Segunda Licenciatura", origin: "Facebook", score: 91, phone: "(48) 9 9933-1180" },
    { name: "Bruno Tavares", course: "Capacitação Corporativa", origin: "LinkedIn", score: 84, phone: "(11) 9 9988-7711" },
  ]},
  { id: "matriculado", label: "Matriculado", color: "bg-emerald-500", leads: [
    { name: "Camila Duarte", course: "MBA Gestão Educacional", origin: "Indicação", score: 96, phone: "(41) 9 9622-1144" },
  ]},
];

function CRM() {
  return (
    <>
      <PageHeader
        eyebrow="Comercial"
        title="CRM — Pipeline de captação"
        description="Acompanhe leads do primeiro contato até a matrícula. Integrado com WhatsApp, telefonia e formulários."
        actions={
          <>
            <Button variant="outline" size="sm"><Filter className="h-4 w-4" /> Filtros</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Novo lead</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Leads novos (mês)" value="847" hint="+18% MoM" icon={Briefcase} accent="text-blue-600" />
          <StatCard label="Taxa de conversão" value="12,4%" hint="Lead → matrícula" icon={Target} accent="text-emerald-600" />
          <StatCard label="Ticket médio" value="R$ 6.840" hint="Curso anual" icon={TrendingUp} accent="text-violet-600" />
          <StatCard label="Consultores ativos" value="24" hint="6 polos" icon={Users} accent="text-amber-600" />
        </section>

        <section className="grid gap-4 lg:grid-cols-4">
          {stages.map((s) => (
            <div key={s.id} className="rounded-2xl border border-border bg-card p-4 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${s.color}`} />
                  <h3 className="text-sm font-semibold">{s.label}</h3>
                </div>
                <span className="rounded-full bg-secondary px-2 py-0.5 text-xs font-medium">{s.leads.length}</span>
              </div>
              <div className="space-y-2.5">
                {s.leads.map((l) => (
                  <article key={l.name} className="cursor-pointer rounded-lg border border-border/70 bg-background p-3 transition-all hover:shadow-md">
                    <div className="flex items-start justify-between">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{l.name}</p>
                        <p className="truncate text-xs text-muted-foreground">{l.course}</p>
                      </div>
                      <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[10px] font-bold text-primary">{l.score}</span>
                    </div>
                    <p className="mt-1.5 text-[11px] text-muted-foreground">Origem: {l.origin}</p>
                    <div className="mt-3 flex items-center gap-1.5">
                      <button className="rounded p-1.5 text-muted-foreground hover:bg-secondary hover:text-primary"><MessageCircle className="h-3.5 w-3.5" /></button>
                      <button className="rounded p-1.5 text-muted-foreground hover:bg-secondary hover:text-primary"><Phone className="h-3.5 w-3.5" /></button>
                      <button className="rounded p-1.5 text-muted-foreground hover:bg-secondary hover:text-primary"><Mail className="h-3.5 w-3.5" /></button>
                      <span className="ml-auto text-[10px] text-muted-foreground">{l.phone}</span>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </section>
      </div>
    </>
  );
}