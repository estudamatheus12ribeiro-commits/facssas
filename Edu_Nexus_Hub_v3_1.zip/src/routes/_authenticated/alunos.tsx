import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Users, UserPlus, Download, Search, GraduationCap, UserCheck, UserX } from "lucide-react";
import { useAlunos } from "@/lib/api/queries";
import { LoadingState, EmptyState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/alunos")({
  head: () => ({ meta: [{ title: "Alunos — FACULTECH" }] }),
  component: Alunos,
});

const statusColor: Record<string, string> = {
  Ativo: "bg-emerald-500/10 text-emerald-700",
  Inadimplente: "bg-amber-500/10 text-amber-700",
  Trancado: "bg-slate-500/10 text-slate-700",
};

function Alunos() {
  const { data: alunos, isLoading, isError, error } = useAlunos();

  const total = alunos?.length ?? 0;
  const ativos = alunos?.filter((a) => a.status === "Ativo").length ?? 0;
  const inadimplentes = alunos?.filter((a) => a.status === "Inadimplente").length ?? 0;
  const trancados = alunos?.filter((a) => a.status === "Trancado").length ?? 0;

  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Gestão de alunos"
        description="Cadastro unificado, situação acadêmica, financeira e progresso por curso."
        actions={
          <>
            <Button variant="outline" size="sm"><Download className="h-4 w-4" /> Exportar CSV</Button>
            <Button variant="hero" size="sm"><UserPlus className="h-4 w-4" /> Novo aluno</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Alunos cadastrados" value={total.toLocaleString("pt-BR")} icon={Users} accent="text-blue-600" />
          <StatCard label="Ativos" value={ativos.toLocaleString("pt-BR")} icon={UserCheck} accent="text-emerald-600" />
          <StatCard label="Inadimplentes" value={inadimplentes.toLocaleString("pt-BR")} icon={UserX} accent="text-amber-600" />
          <StatCard label="Trancados" value={trancados.toLocaleString("pt-BR")} icon={GraduationCap} accent="text-violet-600" />
        </section>

        {isLoading && <LoadingState label="Carregando alunos…" />}
        {isError && <ErrorState message={(error as Error)?.message} />}
        {!isLoading && !isError && total === 0 && (
          <EmptyState title="Nenhum aluno cadastrado" description="Rode a migration de seed no Supabase ou cadastre o primeiro aluno." />
        )}

        {!isLoading && !isError && total > 0 && (
          <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
            <div className="flex flex-wrap items-center gap-3 border-b border-border p-4">
              <div className="relative flex-1 min-w-[240px]">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input placeholder="Buscar por nome, RA ou CPF…" className="h-9 w-full rounded-md border border-input bg-background pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">RA</th>
                    <th className="px-4 py-3">Nome</th>
                    <th className="px-4 py-3">Curso</th>
                    <th className="px-4 py-3">Polo</th>
                    <th className="px-4 py-3">Progresso</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {alunos!.map((a) => (
                    <tr key={a.ra} className="border-t border-border hover:bg-secondary/30">
                      <td className="px-4 py-3 font-mono text-xs">{a.ra}</td>
                      <td className="px-4 py-3 font-medium">{a.nome}</td>
                      <td className="px-4 py-3 text-muted-foreground">{a.curso}</td>
                      <td className="px-4 py-3 text-muted-foreground">{a.polo}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-24 rounded-full bg-secondary">
                            <div className="h-full rounded-full bg-[image:var(--gradient-primary)]" style={{ width: `${a.progresso}%` }} />
                          </div>
                          <span className="text-xs text-muted-foreground">{a.progresso}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusColor[a.status] ?? "bg-secondary text-foreground"}`}>{a.status}</span></td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="ghost" size="sm" asChild>
                          <Link to="/alunos/$ra" params={{ ra: a.ra }}>Abrir</Link>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between border-t border-border p-4 text-sm text-muted-foreground">
              <span>Mostrando {total} {total === 1 ? "aluno" : "alunos"}</span>
            </div>
          </div>
        )}

        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-5 w-5 text-primary" />
            <h2 className="font-display text-lg font-semibold">Aproveitamento curricular automatizado</h2>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">A IA analisa históricos anteriores e sugere disciplinas equivalentes para alunos transferidos.</p>
          <Button variant="hero" size="sm" className="mt-4">Revisar sugestões</Button>
        </div>
      </div>
    </>
  );
}
