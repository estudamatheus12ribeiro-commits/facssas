import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  Briefcase, FileCheck2, Users, GraduationCap, Upload, Plus,
  Building2, CalendarClock, FileSignature, AlertTriangle,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/estagio")({
  head: () => ({ meta: [{ title: "Estágio & TCC — FACULTECH" }] }),
  component: Estagio,
});

const estagios = [
  { aluno: "Ana Beatriz Lima", curso: "Pedagogia EAD", empresa: "EMEI Vila Mariana", orientador: "Dra. Helena Castro", horas: "180/300h", status: "Em andamento" },
  { aluno: "Bruno Carvalho", curso: "MBA Gestão Educacional", empresa: "Colégio Sigma", orientador: "Prof. Carlos Mendes", horas: "240/240h", status: "Concluído" },
  { aluno: "Diego Ferreira", curso: "Engenharia Software", empresa: "Stone Pagamentos", orientador: "Prof. Rafael Tavares", horas: "60/360h", status: "Convênio pendente" },
  { aluno: "Eduarda Martins", curso: "Segunda Licenciatura", empresa: "EE Maria Aparecida", orientador: "Dra. Mariana Souza", horas: "120/200h", status: "Em andamento" },
] as const;

const tccs = [
  { aluno: "Camila Duarte", tema: "Neurociência aplicada à alfabetização", orientador: "Dra. Patrícia Lima", banca: "Agendada 12/06", status: "Em defesa" },
  { aluno: "Gabriela Rocha", tema: "Branding emocional em mídias sociais", orientador: "Prof. André Costa", banca: "—", status: "Revisão final" },
  { aluno: "Henrique Sales", tema: "Formação continuada de docentes", orientador: "Dra. Helena Castro", banca: "—", status: "Capítulo 2" },
  { aluno: "Larissa Oliveira", tema: "Gestão de evasão em EAD", orientador: "Dra. Mariana Souza", banca: "Aprovado 28/05", status: "Aprovado" },
] as const;

const badge = (s: string) => {
  const t = s.toLowerCase();
  if (t.includes("aprov") || t.includes("conclu")) return "bg-emerald-100 text-emerald-700";
  if (t.includes("pend")) return "bg-amber-100 text-amber-700";
  if (t.includes("defesa") || t.includes("agend")) return "bg-violet-100 text-violet-700";
  return "bg-blue-100 text-blue-700";
};

function Estagio() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Estágio supervisionado & TCC"
        description="Convênios, plano de estágio, ficha de frequência, orientação de TCC e bancas."
        actions={
          <>
            <Button variant="outline" size="sm"><Upload className="h-4 w-4" /> Importar convênio</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Novo registro</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Estágios ativos" value="284" icon={Briefcase} accent="text-blue-600" />
          <StatCard label="Convênios firmados" value="62" icon={Building2} accent="text-emerald-600" />
          <StatCard label="TCCs em orientação" value="148" icon={FileSignature} accent="text-violet-600" />
          <StatCard label="Bancas agendadas" value="21" icon={CalendarClock} accent="text-amber-600" />
        </section>

        <section className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
          <div className="flex-1 text-sm">
            <p className="font-semibold text-amber-900">9 fichas de frequência vencerão nos próximos 7 dias</p>
            <p className="text-amber-800">Notifique os supervisores de campo para assinatura digital via portal.</p>
          </div>
          <Button variant="outline" size="sm">Ver lista</Button>
        </section>

        <section className="rounded-2xl border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-6 py-4">
            <div>
              <h2 className="text-sm font-semibold">Estágios supervisionados</h2>
              <p className="text-xs text-muted-foreground">Acompanhamento de campo com carga horária e supervisor.</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
              <Users className="h-3.5 w-3.5" /> 4 de 284
            </span>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Aluno</th>
                <th className="px-4 py-3">Curso</th>
                <th className="px-4 py-3">Empresa / Escola</th>
                <th className="px-4 py-3">Orientador</th>
                <th className="px-4 py-3">Carga horária</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {estagios.map((e) => (
                <tr key={e.aluno} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-medium">{e.aluno}</td>
                  <td className="px-4 py-3 text-muted-foreground">{e.curso}</td>
                  <td className="px-4 py-3">{e.empresa}</td>
                  <td className="px-4 py-3 text-muted-foreground">{e.orientador}</td>
                  <td className="px-4 py-3 font-mono text-xs">{e.horas}</td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${badge(e.status)}`}>{e.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="rounded-2xl border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-6 py-4">
            <div>
              <h2 className="text-sm font-semibold">Trabalhos de conclusão (TCC)</h2>
              <p className="text-xs text-muted-foreground">Orientação, antiplágio com IA e bancas avaliadoras.</p>
            </div>
            <Button variant="outline" size="sm"><FileCheck2 className="h-4 w-4" /> Rodar antiplágio</Button>
          </div>
          <div className="grid gap-3 p-4 sm:grid-cols-2">
            {tccs.map((t) => (
              <article key={t.aluno} className="rounded-xl border border-border bg-background p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-xs uppercase tracking-wider text-muted-foreground">{t.aluno}</p>
                    <p className="mt-1 font-medium leading-tight">{t.tema}</p>
                  </div>
                  <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium ${badge(t.status)}`}>{t.status}</span>
                </div>
                <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><GraduationCap className="h-3.5 w-3.5" /> {t.orientador}</span>
                  <span className="inline-flex items-center gap-1"><CalendarClock className="h-3.5 w-3.5" /> {t.banca}</span>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}