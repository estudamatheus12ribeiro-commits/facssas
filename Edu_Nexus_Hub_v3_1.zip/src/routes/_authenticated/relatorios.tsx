import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { BarChart3, PieChart, TrendingUp, Download, FileSpreadsheet } from "lucide-react";

export const Route = createFileRoute("/_authenticated/relatorios")({
  head: () => ({ meta: [{ title: "Relatórios & BI — FACULTECH" }] }),
  component: Relatorios,
});

const relatorios = [
  { nome: "DRE consolidado", area: "Financeiro", periodo: "Maio/2026", formato: "PDF" },
  { nome: "Captação por origem", area: "Comercial", periodo: "Últimos 30 dias", formato: "XLSX" },
  { nome: "Evasão por curso", area: "Acadêmico", periodo: "Semestre 2026.1", formato: "PDF" },
  { nome: "Desempenho por polo", area: "Operação", periodo: "Maio/2026", formato: "XLSX" },
  { nome: "Inadimplência detalhada", area: "Financeiro", periodo: "Mai/2026", formato: "PDF" },
  { nome: "Avaliação docente", area: "Acadêmico", periodo: "2026.1", formato: "PDF" },
];

function Relatorios() {
  return (
    <>
      <PageHeader
        eyebrow="Visão geral"
        title="Relatórios & Business Intelligence"
        description="Dashboards executivos, análises preditivas e relatórios regulatórios prontos para o MEC."
        actions={<Button variant="hero" size="sm"><Download className="h-4 w-4" /> Exportar tudo</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Dashboards ativos" value="34" icon={BarChart3} accent="text-blue-600" />
          <StatCard label="Relatórios gerados (mês)" value="1.847" icon={FileSpreadsheet} accent="text-violet-600" />
          <StatCard label="Forecast receita 2026" value="R$ 62M" hint="+24% YoY" icon={TrendingUp} accent="text-emerald-600" />
          <StatCard label="KPIs monitorados" value="128" icon={PieChart} accent="text-amber-600" />
        </section>

        <section className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="mb-4 font-display text-lg font-semibold">Receita por modalidade — semestre</h2>
            <div className="flex h-56 items-end gap-4">
              {[
                { l: "Grad.", v: 90, c: "bg-blue-500" },
                { l: "Pós", v: 70, c: "bg-violet-500" },
                { l: "Téc.", v: 38, c: "bg-emerald-500" },
                { l: "Livre", v: 52, c: "bg-amber-500" },
                { l: "EJA", v: 24, c: "bg-rose-500" },
                { l: "Corp.", v: 64, c: "bg-cyan-500" },
              ].map((b) => (
                <div key={b.l} className="flex flex-1 flex-col items-center gap-2">
                  <div className={`w-full rounded-t ${b.c}`} style={{ height: `${b.v * 2}px` }} />
                  <span className="text-xs text-muted-foreground">{b.l}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="mb-4 font-display text-lg font-semibold">Indicadores acadêmicos</h2>
            <div className="grid grid-cols-2 gap-3">
              {[
                { l: "Taxa de aprovação", v: "87,4%" },
                { l: "Conclusão de curso", v: "72,1%" },
                { l: "NPS aluno", v: "71" },
                { l: "Avaliação docente", v: "4,7/5" },
                { l: "Frequência média", v: "91,2%" },
                { l: "Tempo médio resposta", v: "1,8h" },
              ].map((k) => (
                <div key={k.l} className="rounded-xl border border-border/60 bg-secondary/40 p-4">
                  <p className="text-xs text-muted-foreground">{k.l}</p>
                  <p className="mt-1 font-display text-xl font-bold">{k.v}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <div className="border-b border-border p-4"><h2 className="font-display text-lg font-semibold">Biblioteca de relatórios</h2></div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr><th className="px-4 py-3">Relatório</th><th className="px-4 py-3">Área</th><th className="px-4 py-3">Período</th><th className="px-4 py-3">Formato</th><th></th></tr>
            </thead>
            <tbody>
              {relatorios.map((r) => (
                <tr key={r.nome} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-medium">{r.nome}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.area}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.periodo}</td>
                  <td className="px-4 py-3"><span className="rounded bg-primary/10 px-2 py-0.5 font-mono text-xs text-primary">{r.formato}</span></td>
                  <td className="px-4 py-3 text-right"><Button variant="ghost" size="sm"><Download className="h-4 w-4" /> Baixar</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}