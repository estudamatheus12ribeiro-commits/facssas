import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { BookOpen, Plus, Clock, Award, Layers } from "lucide-react";
import { useCursos } from "@/lib/api/queries";
import { LoadingState, EmptyState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/cursos")({
  head: () => ({ meta: [{ title: "Cursos — FACULTECH" }] }),
  component: Cursos,
});

function Cursos() {
  const { data: cursos, isLoading, isError, error } = useCursos();

  const total = cursos?.length ?? 0;
  const ativos = cursos?.filter((c) => c.status === "Ativo").length ?? 0;
  const disciplinas = cursos?.reduce((s, c) => s + (c.disciplinas ?? 0), 0) ?? 0;
  const matriculados = cursos?.reduce((s, c) => s + (c.alunos ?? 0), 0) ?? 0;

  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Catálogo de cursos"
        description="Graduação, pós, técnicos, livres e capacitações corporativas em uma única estrutura."
        actions={<Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Novo curso</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Cursos ativos" value={ativos.toLocaleString("pt-BR")} icon={BookOpen} accent="text-blue-600" />
          <StatCard label="Disciplinas" value={disciplinas.toLocaleString("pt-BR")} icon={Layers} accent="text-violet-600" />
          <StatCard label="Total de cursos" value={total.toLocaleString("pt-BR")} icon={Clock} accent="text-amber-600" />
          <StatCard label="Alunos matriculados" value={matriculados.toLocaleString("pt-BR")} icon={Award} accent="text-emerald-600" />
        </section>

        {isLoading && <LoadingState label="Carregando cursos…" />}
        {isError && <ErrorState message={(error as Error)?.message} />}
        {!isLoading && !isError && total === 0 && (
          <EmptyState title="Nenhum curso cadastrado" description="Rode a migration de seed no Supabase ou crie o primeiro curso." />
        )}

        {!isLoading && !isError && total > 0 && (
          <section className="grid gap-5 lg:grid-cols-2 xl:grid-cols-3">
            {cursos!.map((c) => (
              <article key={c.id} className="group overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-card)]">
                <div className="relative h-28" style={{ backgroundImage: "var(--gradient-hero)" }}>
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,oklch(0.65_0.22_258/0.55),transparent_70%)]" />
                  <div className="absolute left-4 top-4 rounded-full bg-white/15 px-2.5 py-0.5 text-xs font-medium text-white backdrop-blur">{c.modalidade}</div>
                  <span className={`absolute right-4 top-4 rounded-full px-2.5 py-0.5 text-xs font-medium ${c.status === "Ativo" ? "bg-emerald-500/90 text-white" : "bg-amber-500/90 text-white"}`}>{c.status}</span>
                </div>
                <div className="p-5">
                  <h3 className="font-display text-lg font-semibold leading-tight">{c.titulo}</h3>
                  <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-lg bg-secondary/50 p-2">
                      <p className="text-[10px] uppercase text-muted-foreground">Carga</p>
                      <p className="text-sm font-semibold">{c.carga}</p>
                    </div>
                    <div className="rounded-lg bg-secondary/50 p-2">
                      <p className="text-[10px] uppercase text-muted-foreground">Alunos</p>
                      <p className="text-sm font-semibold">{(c.alunos ?? 0).toLocaleString("pt-BR")}</p>
                    </div>
                    <div className="rounded-lg bg-secondary/50 p-2">
                      <p className="text-[10px] uppercase text-muted-foreground">Disc.</p>
                      <p className="text-sm font-semibold">{c.disciplinas}</p>
                    </div>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" asChild>
                      <Link to="/cursos/$slug" params={{ slug: c.slug }}>Matriz</Link>
                    </Button>
                    <Button variant="hero" size="sm" className="flex-1" asChild>
                      <Link to="/cursos/$slug" params={{ slug: c.slug }}>Abrir</Link>
                    </Button>
                  </div>
                </div>
              </article>
            ))}
          </section>
        )}
      </div>
    </>
  );
}
