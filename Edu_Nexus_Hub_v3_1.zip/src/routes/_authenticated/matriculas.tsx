import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  ClipboardList, FileSignature, CheckCircle2, Clock, Plus, FileText,
  CreditCard, GraduationCap, Search, Filter, Download, AlertTriangle, TrendingUp,
} from "lucide-react";
import { useMatriculas } from "@/lib/api/queries";
import { LoadingState, EmptyState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/matriculas")({
  head: () => ({ meta: [{ title: "Matrículas — FACULTECH" }] }),
  component: Matriculas,
});

const etapaMeta = [
  { key: "Documentos", icon: FileText, color: "text-blue-600", bg: "bg-blue-50" },
  { key: "Contrato", icon: FileSignature, color: "text-amber-600", bg: "bg-amber-50" },
  { key: "Pagamento", icon: CreditCard, color: "text-violet-600", bg: "bg-violet-50" },
  { key: "Concluída", icon: GraduationCap, color: "text-emerald-600", bg: "bg-emerald-50" },
] as const;

const filtros = ["Todas", "Documentos", "Contrato", "Pagamento", "Concluída", "Canceladas"] as const;

const statusBadge = (status: string) => {
  const s = (status || "").toLowerCase();
  if (s.includes("matricul")) return "bg-emerald-100 text-emerald-700";
  if (s.includes("vencid") || s.includes("cancel")) return "bg-rose-100 text-rose-700";
  if (s.includes("análise") || s.includes("pendente") || s.includes("aguard")) return "bg-amber-100 text-amber-700";
  return "bg-secondary text-foreground";
};

function Matriculas() {
  const { data: matriculas, isLoading, isError, error } = useMatriculas();

  const total = matriculas?.length ?? 0;
  const concluidas = matriculas?.filter((m) => m.etapa === "Concluída").length ?? 0;
  const emProcesso = total - concluidas;
  const count = (key: string) => matriculas?.filter((m) => m.etapa === key).length ?? 0;

  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Processos de matrícula"
        description="Fluxo completo: documentação, contrato digital, pagamento e ativação no AVA."
        actions={
          <>
            <Button variant="outline" size="sm"><Download className="h-4 w-4" /> Exportar</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nova matrícula</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Matrículas" value={total.toLocaleString("pt-BR")} icon={ClipboardList} accent="text-blue-600" />
          <StatCard label="Concluídas" value={concluidas.toLocaleString("pt-BR")} icon={FileSignature} accent="text-emerald-600" />
          <StatCard label="Em processamento" value={emProcesso.toLocaleString("pt-BR")} icon={Clock} accent="text-amber-600" />
          <StatCard label="Tempo médio" value="2,4 dias" icon={CheckCircle2} accent="text-violet-600" />
        </section>

        <section className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold">Pipeline de matrículas</h2>
              <p className="text-xs text-muted-foreground">Acompanhe a evolução por etapa do funil acadêmico.</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
              <TrendingUp className="h-3.5 w-3.5" /> funil em tempo real
            </span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {etapaMeta.map((e, idx) => (
              <div key={e.key} className="relative rounded-xl border border-border bg-background p-4">
                <div className={`mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg ${e.bg}`}>
                  <e.icon className={`h-4 w-4 ${e.color}`} />
                </div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">Etapa {idx + 1}</p>
                <p className="text-sm font-semibold">{e.key}</p>
                <p className="mt-2 text-2xl font-bold">{count(e.key)}</p>
                <p className="text-xs text-muted-foreground">processos</p>
              </div>
            ))}
          </div>
        </section>

        <section className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-2">
            {filtros.map((f, i) => (
              <button key={f} className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${i === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}>
                {f}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input placeholder="Buscar protocolo, aluno ou curso..." className="h-9 w-72 rounded-lg border border-border bg-background pl-8 pr-3 text-xs outline-none focus:border-primary" />
            </div>
            <Button variant="outline" size="sm"><Filter className="h-4 w-4" /> Filtros</Button>
          </div>
        </section>

        {isLoading && <LoadingState label="Carregando matrículas…" />}
        {isError && <ErrorState message={(error as Error)?.message} />}
        {!isLoading && !isError && total === 0 && (
          <EmptyState title="Nenhuma matrícula registrada" description="Rode a migration de seed no Supabase ou inicie uma nova matrícula." />
        )}

        {!isLoading && !isError && total > 0 && (
          <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Protocolo</th>
                    <th className="px-4 py-3">Aluno</th>
                    <th className="px-4 py-3">Curso</th>
                    <th className="px-4 py-3">Responsável</th>
                    <th className="px-4 py-3">Valor</th>
                    <th className="px-4 py-3">Data</th>
                    <th className="px-4 py-3">Etapa</th>
                    <th className="px-4 py-3">Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {matriculas!.map((m) => (
                    <tr key={m.proto} className="border-t border-border hover:bg-secondary/30">
                      <td className="px-4 py-3 font-mono text-xs">{m.proto}</td>
                      <td className="px-4 py-3 font-medium">{m.aluno}</td>
                      <td className="px-4 py-3 text-muted-foreground">{m.curso}</td>
                      <td className="px-4 py-3 text-muted-foreground">{m.responsavel}</td>
                      <td className="px-4 py-3">
                        <div className="font-medium">{m.valor}</div>
                        <div className="text-xs text-muted-foreground">{m.parcelas}</div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{m.data}</td>
                      <td className="px-4 py-3"><span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">{m.etapa}</span></td>
                      <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusBadge(m.status ?? "")}`}>{m.status}</span></td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="ghost" size="sm" asChild>
                          <Link to="/matriculas/$proto" params={{ proto: m.proto }}>Abrir</Link>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between border-t border-border bg-secondary/20 px-4 py-3 text-xs text-muted-foreground">
              <span>Exibindo {total} {total === 1 ? "matrícula" : "matrículas"}</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
