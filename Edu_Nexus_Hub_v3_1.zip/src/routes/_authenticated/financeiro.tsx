import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Wallet, TrendingUp, AlertTriangle, FileText, Download, Plus } from "lucide-react";

export const Route = createFileRoute("/_authenticated/financeiro")({
  head: () => ({ meta: [{ title: "Financeiro — FACULTECH" }] }),
  component: Financeiro,
});

const boletos = [
  { aluno: "Ana Beatriz Lima", valor: "R$ 489,00", venc: "05/06/2026", status: "Pago" },
  { aluno: "Bruno Carvalho", valor: "R$ 749,00", venc: "07/06/2026", status: "Em aberto" },
  { aluno: "Diego Ferreira", valor: "R$ 489,00", venc: "20/05/2026", status: "Vencido" },
  { aluno: "Eduarda Martins", valor: "R$ 599,00", venc: "10/06/2026", status: "Em aberto" },
  { aluno: "Henrique Sales", valor: "R$ 489,00", venc: "01/06/2026", status: "Pago" },
];

const statusColor: Record<string, string> = {
  Pago: "bg-emerald-500/10 text-emerald-700",
  "Em aberto": "bg-blue-500/10 text-blue-700",
  Vencido: "bg-destructive/10 text-destructive",
};

function Financeiro() {
  return (
    <>
      <PageHeader
        eyebrow="Operação"
        title="Gestão financeira"
        description="Mensalidades, comissões de polos, repasses e régua de cobrança integrada."
        actions={
          <>
            <Button variant="outline" size="sm"><Download className="h-4 w-4" /> DRE</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Lançamento</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Receita do mês" value="R$ 4,82M" hint="+12,1% MoM" icon={Wallet} accent="text-emerald-600" />
          <StatCard label="A receber (30d)" value="R$ 6,14M" icon={TrendingUp} accent="text-blue-600" />
          <StatCard label="Inadimplência" value="3,8%" hint="R$ 184k" icon={AlertTriangle} accent="text-destructive" />
          <StatCard label="Comissões a pagar" value="R$ 312k" hint="47 polos" icon={FileText} accent="text-violet-600" />
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="mb-4 font-display text-lg font-semibold">Fluxo de caixa — 6 meses</h2>
            <div className="flex h-48 items-end gap-3">
              {[3.2, 3.8, 3.5, 4.1, 4.5, 4.82].map((v, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-2">
                  <div className="w-full rounded-t bg-[image:var(--gradient-primary)]" style={{ height: `${v * 30}px` }} />
                  <span className="text-xs text-muted-foreground">{["Jan","Fev","Mar","Abr","Mai","Jun"][i]}</span>
                  <span className="text-[10px] font-medium">R${v}M</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="mb-4 font-display text-lg font-semibold">Distribuição de receita</h2>
            <div className="space-y-3">
              {[
                { l: "Graduação EAD", p: 42, c: "bg-blue-500" },
                { l: "Pós-Graduação", p: 28, c: "bg-violet-500" },
                { l: "Cursos Livres", p: 14, c: "bg-emerald-500" },
                { l: "Corporativo", p: 11, c: "bg-amber-500" },
                { l: "EJA & Técnicos", p: 5, c: "bg-slate-500" },
              ].map((r) => (
                <div key={r.l}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span>{r.l}</span><span className="font-medium">{r.p}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-secondary">
                    <div className={`h-full rounded-full ${r.c}`} style={{ width: `${r.p}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <div className="border-b border-border p-4">
            <h2 className="font-display text-lg font-semibold">Boletos recentes</h2>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr><th className="px-4 py-3">Aluno</th><th className="px-4 py-3">Valor</th><th className="px-4 py-3">Vencimento</th><th className="px-4 py-3">Status</th><th></th></tr>
            </thead>
            <tbody>
              {boletos.map((b) => (
                <tr key={b.aluno} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-medium">{b.aluno}</td>
                  <td className="px-4 py-3 font-mono">{b.valor}</td>
                  <td className="px-4 py-3 text-muted-foreground">{b.venc}</td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusColor[b.status]}`}>{b.status}</span></td>
                  <td className="px-4 py-3 text-right"><Button variant="ghost" size="sm">Detalhes</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}