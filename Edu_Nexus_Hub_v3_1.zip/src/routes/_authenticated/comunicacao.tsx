import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { MessageSquare, Send, CheckCheck, Bot, Plus } from "lucide-react";

export const Route = createFileRoute("/_authenticated/comunicacao")({
  head: () => ({ meta: [{ title: "Comunicação — FACULTECH" }] }),
  component: Comunicacao,
});

const conversas = [
  { nome: "Mariana Souza", ultima: "Posso parcelar a matrícula em 12x?", hora: "10:42", nao: 2, canal: "WhatsApp" },
  { nome: "Carlos Eduardo Lima", ultima: "Recebi o link, obrigado!", hora: "10:18", nao: 0, canal: "WhatsApp" },
  { nome: "Juliana Reis", ultima: "Gostaria de saber sobre a pós em psicopedagogia", hora: "09:55", nao: 1, canal: "Instagram" },
  { nome: "André Pinto", ultima: "Bom dia, sobre o EJA…", hora: "09:30", nao: 3, canal: "WhatsApp" },
  { nome: "Fernanda Castro", ultima: "Pode enviar o contrato?", hora: "Ontem", nao: 0, canal: "WhatsApp" },
];

const campanhas = [
  { nome: "Vestibular 2026.2 — Aquecimento", envio: "12.4k", abertura: "62%", resposta: "18%" },
  { nome: "Régua de inadimplência D+5", envio: "412", abertura: "78%", resposta: "34%" },
  { nome: "Reativação ex-alunos", envio: "2.1k", abertura: "44%", resposta: "9%" },
];

function Comunicacao() {
  return (
    <>
      <PageHeader
        eyebrow="Comercial"
        title="WhatsApp & Comunicação"
        description="Atendimento omnichannel, campanhas em massa, automações com IA e régua de relacionamento."
        actions={<Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nova campanha</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Conversas hoje" value="847" icon={MessageSquare} accent="text-blue-600" />
          <StatCard label="Mensagens enviadas" value="14.2k" icon={Send} accent="text-violet-600" />
          <StatCard label="Taxa de resposta" value="92%" icon={CheckCheck} accent="text-emerald-600" />
          <StatCard label="Atendimentos pela IA" value="61%" icon={Bot} accent="text-amber-600" />
        </section>

        <section className="grid gap-6 lg:grid-cols-3">
          <div className="rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
            <div className="border-b border-border p-4"><h2 className="font-display font-semibold">Caixa de entrada</h2></div>
            <ul className="divide-y divide-border">
              {conversas.map((c) => (
                <li key={c.nome} className="flex items-start gap-3 p-3 hover:bg-secondary/30">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">{c.nome.split(" ").slice(0,2).map(s=>s[0]).join("")}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between"><p className="truncate text-sm font-medium">{c.nome}</p><span className="text-[10px] text-muted-foreground">{c.hora}</span></div>
                    <p className="truncate text-xs text-muted-foreground">{c.ultima}</p>
                    <span className="mt-1 inline-block rounded bg-secondary px-1.5 py-0.5 text-[10px]">{c.canal}</span>
                  </div>
                  {c.nao > 0 && <span className="rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground">{c.nao}</span>}
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2 rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
            <div className="border-b border-border p-4"><h2 className="font-display font-semibold">Campanhas ativas</h2></div>
            <table className="w-full text-sm">
              <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr><th className="px-4 py-3">Campanha</th><th className="px-4 py-3">Envios</th><th className="px-4 py-3">Abertura</th><th className="px-4 py-3">Resposta</th><th></th></tr>
              </thead>
              <tbody>
                {campanhas.map((c) => (
                  <tr key={c.nome} className="border-t border-border hover:bg-secondary/30">
                    <td className="px-4 py-3 font-medium">{c.nome}</td>
                    <td className="px-4 py-3">{c.envio}</td>
                    <td className="px-4 py-3 text-emerald-700">{c.abertura}</td>
                    <td className="px-4 py-3 text-violet-700">{c.resposta}</td>
                    <td className="px-4 py-3 text-right"><Button variant="ghost" size="sm">Ver</Button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </>
  );
}