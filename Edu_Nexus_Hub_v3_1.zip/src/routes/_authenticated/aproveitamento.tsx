import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  GitCompareArrows,
  Sparkles,
  FileCheck2,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Upload,
  ArrowRight,
  Percent,
  BookOpenCheck,
  ShieldCheck,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/aproveitamento")({
  head: () => ({ meta: [{ title: "Aproveitamento de Estudos — FACULTECH" }] }),
  component: Aproveitamento,
});

const solicitacoes = [
  { id: "APR-2026-0421", aluno: "Larissa Oliveira", ra: "2024021", cursoOrigem: "Licenciatura em Letras (USP)", cursoDestino: "Pedagogia EAD", disciplinas: 8, equivalentes: 6, status: "Em análise", data: "29/05/2026", parecerista: "Dra. Mariana Souza" },
  { id: "APR-2026-0422", aluno: "Marcos Vinícius", ra: "2024022", cursoOrigem: "Administração (FGV)", cursoDestino: "MBA Gestão Educacional", disciplinas: 5, equivalentes: 5, status: "Aprovado", data: "28/05/2026", parecerista: "Prof. Carlos Mendes" },
  { id: "APR-2026-0423", aluno: "Patrícia Gomes", ra: "2024023", cursoOrigem: "Psicologia (PUC)", cursoDestino: "Pós Psicopedagogia", disciplinas: 6, equivalentes: 4, status: "Parcial", data: "27/05/2026", parecerista: "Dra. Patrícia Lima" },
  { id: "APR-2026-0424", aluno: "Ricardo Almeida", ra: "2024024", cursoOrigem: "Ciência da Computação (UFMG)", cursoDestino: "Engenharia de Software", disciplinas: 10, equivalentes: 9, status: "Aprovado", data: "26/05/2026", parecerista: "Prof. Rafael Tavares" },
  { id: "APR-2026-0425", aluno: "Fernanda Lopes", ra: "2024025", cursoOrigem: "Marketing (ESPM)", cursoDestino: "Tecnólogo em Marketing", disciplinas: 4, equivalentes: 0, status: "Reprovado", data: "26/05/2026", parecerista: "Prof. Carlos Mendes" },
  { id: "APR-2026-0426", aluno: "Gustavo Henrique", ra: "2024026", cursoOrigem: "História (UFRJ)", cursoDestino: "Segunda Licenciatura História", disciplinas: 12, equivalentes: 10, status: "Em análise", data: "25/05/2026", parecerista: "Dra. Helena Castro" },
];

const equivalencias = [
  { origem: "Didática Geral", origemCarga: "60h", destino: "Didática do Ensino Superior", destinoCarga: "60h", aderencia: 94, status: "match" },
  { origem: "Psicologia da Educação I", origemCarga: "80h", destino: "Psicologia da Aprendizagem", destinoCarga: "80h", aderencia: 88, status: "match" },
  { origem: "Sociologia da Educação", origemCarga: "60h", destino: "Fundamentos Sociológicos", destinoCarga: "60h", aderencia: 76, status: "match" },
  { origem: "Filosofia da Educação", origemCarga: "60h", destino: "Filosofia da Educação", destinoCarga: "80h", aderencia: 68, status: "parcial" },
  { origem: "História da Educação Brasileira", origemCarga: "40h", destino: "História da Educação no Brasil", destinoCarga: "60h", aderencia: 52, status: "parcial" },
  { origem: "Marketing Digital Básico", origemCarga: "30h", destino: "Estratégias de Marketing Educacional", destinoCarga: "80h", aderencia: 24, status: "incompativel" },
];

const statusBadge = (s: string) => {
  if (s === "Aprovado") return "bg-emerald-100 text-emerald-700";
  if (s === "Parcial") return "bg-amber-100 text-amber-700";
  if (s === "Reprovado") return "bg-rose-100 text-rose-700";
  if (s === "Em análise") return "bg-blue-100 text-blue-700";
  return "bg-secondary text-foreground";
};

const matchColor = (s: string) => {
  if (s === "match") return { bg: "bg-emerald-50", border: "border-emerald-200", icon: CheckCircle2, color: "text-emerald-600", label: "Compatível" };
  if (s === "parcial") return { bg: "bg-amber-50", border: "border-amber-200", icon: AlertCircle, color: "text-amber-600", label: "Parcial" };
  return { bg: "bg-rose-50", border: "border-rose-200", icon: XCircle, color: "text-rose-600", label: "Incompatível" };
};

function Aproveitamento() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Aproveitamento de estudos & equivalência curricular"
        description="Compare ementas, valide disciplinas cursadas em outras instituições e emita parecer com base na LDB e nas DCNs."
        actions={
          <>
            <Button variant="outline" size="sm"><Upload className="h-4 w-4" /> Importar histórico</Button>
            <Button variant="hero" size="sm"><Sparkles className="h-4 w-4" /> Analisar com IA</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Solicitações (mês)" value="142" icon={GitCompareArrows} accent="text-blue-600" />
          <StatCard label="Aprovadas" value="98" icon={CheckCircle2} accent="text-emerald-600" />
          <StatCard label="Em análise" value="34" icon={Clock} accent="text-amber-600" />
          <StatCard label="Taxa de equivalência" value="73%" icon={Percent} accent="text-violet-600" />
        </section>

        {/* Como funciona */}
        <section className="rounded-2xl border border-border bg-gradient-to-br from-primary/5 to-primary/10 p-6 shadow-sm">
          <div className="mb-4 flex items-start gap-3">
            <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-sm font-semibold">Análise automática com IA Educacional</h2>
              <p className="text-xs text-muted-foreground">
                A IA compara ementas, carga horária e bibliografia das disciplinas cursadas com a matriz do curso de destino,
                sugerindo equivalência total, parcial ou incompatibilidade. Parecer final sempre revisado pelo coordenador.
              </p>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-4">
            {[
              { n: 1, icon: Upload, t: "Upload do histórico", d: "PDF ou XML do MEC" },
              { n: 2, icon: GitCompareArrows, t: "Match de ementas", d: "Comparação semântica IA" },
              { n: 3, icon: BookOpenCheck, t: "Parecer pedagógico", d: "Coordenador valida" },
              { n: 4, icon: ShieldCheck, t: "Registro acadêmico", d: "Lançamento no histórico" },
            ].map((step) => (
              <div key={step.n} className="rounded-xl border border-border bg-card p-4">
                <div className="mb-2 flex items-center gap-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">{step.n}</span>
                  <step.icon className="h-4 w-4 text-primary" />
                </div>
                <p className="text-sm font-semibold">{step.t}</p>
                <p className="text-xs text-muted-foreground">{step.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Comparador de disciplinas */}
        <section className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Análise APR-2026-0421</p>
              <h3 className="text-sm font-semibold">Larissa Oliveira · Letras (USP) → Pedagogia EAD</h3>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">Reanalisar</Button>
              <Button variant="hero" size="sm">Emitir parecer</Button>
            </div>
          </div>

          <div className="space-y-2">
            <div className="grid grid-cols-12 gap-3 px-3 pb-2 text-xs uppercase tracking-wider text-muted-foreground">
              <div className="col-span-4">Disciplina cursada (origem)</div>
              <div className="col-span-1 text-center">→</div>
              <div className="col-span-4">Disciplina destino</div>
              <div className="col-span-2">Aderência</div>
              <div className="col-span-1 text-right">Status</div>
            </div>
            {equivalencias.map((eq, i) => {
              const m = matchColor(eq.status);
              return (
                <div key={i} className={`grid grid-cols-12 items-center gap-3 rounded-xl border ${m.border} ${m.bg} p-3 text-sm`}>
                  <div className="col-span-4">
                    <p className="font-medium">{eq.origem}</p>
                    <p className="text-xs text-muted-foreground">{eq.origemCarga}</p>
                  </div>
                  <div className="col-span-1 flex justify-center">
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="col-span-4">
                    <p className="font-medium">{eq.destino}</p>
                    <p className="text-xs text-muted-foreground">{eq.destinoCarga}</p>
                  </div>
                  <div className="col-span-2">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/60">
                        <div
                          className={`h-full ${eq.status === "match" ? "bg-emerald-500" : eq.status === "parcial" ? "bg-amber-500" : "bg-rose-500"}`}
                          style={{ width: `${eq.aderencia}%` }}
                        />
                      </div>
                      <span className="text-xs font-semibold tabular-nums">{eq.aderencia}%</span>
                    </div>
                  </div>
                  <div className="col-span-1 flex items-center justify-end gap-1">
                    <m.icon className={`h-4 w-4 ${m.color}`} />
                    <span className={`hidden text-xs font-medium xl:inline ${m.color}`}>{m.label}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 flex items-center justify-between rounded-xl border border-border bg-background p-4 text-sm">
            <div>
              <p className="font-semibold">Resumo do parecer</p>
              <p className="text-xs text-muted-foreground">
                3 disciplinas equivalentes · 2 parciais (cursar complementação) · 1 incompatível · Total aproveitado: <span className="font-semibold text-emerald-600">200h de 380h</span>
              </p>
            </div>
            <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-semibold text-emerald-700">
              <CheckCircle2 className="mr-1 inline h-3.5 w-3.5" /> Aproveitamento de 53%
            </span>
          </div>
        </section>

        {/* Lista de solicitações */}
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <h3 className="text-sm font-semibold">Solicitações de aproveitamento</h3>
            <Button variant="ghost" size="sm">Exportar relatório</Button>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Protocolo</th>
                <th className="px-4 py-3">Aluno</th>
                <th className="px-4 py-3">Curso origem → destino</th>
                <th className="px-4 py-3">Equivalência</th>
                <th className="px-4 py-3">Parecerista</th>
                <th className="px-4 py-3">Data</th>
                <th className="px-4 py-3">Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {solicitacoes.map((s) => (
                <tr key={s.id} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-mono text-xs">{s.id}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium">{s.aluno}</p>
                    <p className="text-xs text-muted-foreground">RA {s.ra}</p>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">
                    <p>{s.cursoOrigem}</p>
                    <p className="text-foreground">→ {s.cursoDestino}</p>
                  </td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                      {s.equivalentes}/{s.disciplinas} disciplinas
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{s.parecerista}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{s.data}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusBadge(s.status)}`}>{s.status}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="sm"><FileCheck2 className="h-4 w-4" /> Analisar</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}