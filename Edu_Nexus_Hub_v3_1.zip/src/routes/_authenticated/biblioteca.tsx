import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Library, Book, Download, Search, BookOpen } from "lucide-react";

export const Route = createFileRoute("/_authenticated/biblioteca")({
  head: () => ({ meta: [{ title: "Biblioteca — FACULTECH" }] }),
  component: Biblioteca,
});

const acervo = [
  { titulo: "Didática: O ensino e suas relações", autor: "José Carlos Libâneo", area: "Pedagogia", tipo: "E-book", ano: 2024 },
  { titulo: "Gestão Escolar Democrática", autor: "Vitor Henrique Paro", area: "Gestão", tipo: "E-book", ano: 2023 },
  { titulo: "Avaliação da Aprendizagem na Escola", autor: "Cipriano Luckesi", area: "Avaliação", tipo: "E-book", ano: 2024 },
  { titulo: "Tecnologias e Educação", autor: "Maria Elizabeth Almeida", area: "TI Educacional", tipo: "Artigo", ano: 2025 },
  { titulo: "Psicopedagogia Clínica", autor: "Alicia Fernández", area: "Psicopedagogia", tipo: "E-book", ano: 2023 },
  { titulo: "Educação Inclusiva — Práticas", autor: "Maria Teresa Mantoan", area: "Inclusão", tipo: "E-book", ano: 2024 },
];

function Biblioteca() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Biblioteca digital"
        description="Acervo integrado com referências obrigatórias por disciplina e empréstimos digitais."
        actions={<Button variant="hero" size="sm"><Book className="h-4 w-4" /> Sugerir título</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Títulos no acervo" value="48.214" icon={Library} accent="text-blue-600" />
          <StatCard label="Empréstimos ativos" value="1.847" icon={Book} accent="text-violet-600" />
          <StatCard label="Downloads (mês)" value="12.4k" icon={Download} accent="text-emerald-600" />
          <StatCard label="Áreas do conhecimento" value="42" icon={BookOpen} accent="text-amber-600" />
        </section>

        <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input placeholder="Buscar por título, autor ou ISBN…" className="h-10 w-full rounded-md border border-input bg-background pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </div>
        </div>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {acervo.map((a) => (
            <article key={a.titulo} className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
              <div className="flex h-32 items-center justify-center" style={{ backgroundImage: "var(--gradient-hero)" }}>
                <Book className="h-12 w-12 text-white/80" />
              </div>
              <div className="p-5">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-primary">{a.tipo} · {a.ano}</p>
                <h3 className="mt-1 font-semibold leading-tight">{a.titulo}</h3>
                <p className="text-xs text-muted-foreground">{a.autor}</p>
                <p className="mt-2 inline-block rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium">{a.area}</p>
                <Button variant="outline" size="sm" className="mt-4 w-full">Acessar</Button>
              </div>
            </article>
          ))}
        </section>
      </div>
    </>
  );
}