import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Video, PlayCircle, FileText, MessageSquare, CheckCircle2, Clock, Trophy } from "lucide-react";

export const Route = createFileRoute("/_authenticated/ava")({
  head: () => ({ meta: [{ title: "AVA — FACULTECH" }] }),
  component: AVA,
});

const disciplinas = [
  { nome: "Didática do Ensino Superior", prof: "Dra. Helena Castro", progresso: 78, aulas: "18/24", proxima: "Avaliação 3 — 04/06" },
  { nome: "Gestão de Projetos Educacionais", prof: "Prof. Rafael Tavares", progresso: 56, aulas: "12/22", proxima: "Fórum aberto" },
  { nome: "Tecnologias Educacionais", prof: "Dra. Patrícia Lima", progresso: 92, aulas: "20/22", proxima: "TCC parcial" },
  { nome: "Avaliação da Aprendizagem", prof: "Prof. Carlos Mendes", progresso: 34, aulas: "7/20", proxima: "Aula ao vivo 02/06 19h" },
];

const proximas = [
  { titulo: "Live: Metodologias Ativas", quando: "Hoje · 19h00", prof: "Dra. Helena Castro", tipo: "Ao vivo" },
  { titulo: "Entrega: Resenha crítica", quando: "Amanhã · 23h59", prof: "Tecnologias Educacionais", tipo: "Atividade" },
  { titulo: "Prova 2 — Avaliação", quando: "04/06 · 20h00", prof: "Didática", tipo: "Avaliação" },
];

function AVA() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="AVA — Ambiente Virtual de Aprendizagem"
        description="Sala de aula virtual, videoaulas, fóruns, atividades e avaliações integradas."
        actions={<Button variant="hero" size="sm"><PlayCircle className="h-4 w-4" /> Retomar aula</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Disciplinas no semestre" value="6" icon={Video} accent="text-blue-600" />
          <StatCard label="Progresso médio" value="65%" icon={CheckCircle2} accent="text-emerald-600" />
          <StatCard label="Horas estudadas" value="184h" hint="este semestre" icon={Clock} accent="text-violet-600" />
          <StatCard label="Conquistas" value="12" icon={Trophy} accent="text-amber-600" />
        </section>

        <section className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-3">
            <h2 className="font-display text-lg font-semibold">Minhas disciplinas</h2>
            {disciplinas.map((d) => (
              <article key={d.nome} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold">{d.nome}</h3>
                    <p className="text-xs text-muted-foreground">{d.prof} · {d.aulas} aulas</p>
                  </div>
                  <span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">{d.proxima}</span>
                </div>
                <div className="mt-3 flex items-center gap-3">
                  <Progress value={d.progresso} className="h-1.5 flex-1" />
                  <span className="text-xs font-medium text-muted-foreground">{d.progresso}%</span>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" size="sm"><PlayCircle className="h-4 w-4" /> Aulas</Button>
                  <Button variant="outline" size="sm"><FileText className="h-4 w-4" /> Material</Button>
                  <Button variant="outline" size="sm"><MessageSquare className="h-4 w-4" /> Fórum</Button>
                  <Button variant="hero" size="sm" className="ml-auto">Entrar</Button>
                </div>
              </article>
            ))}
          </div>

          <div className="space-y-3">
            <h2 className="font-display text-lg font-semibold">Próximos compromissos</h2>
            {proximas.map((p) => (
              <div key={p.titulo} className="rounded-2xl border border-border bg-card p-4 shadow-sm">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">{p.tipo}</p>
                <p className="mt-1 font-medium">{p.titulo}</p>
                <p className="text-xs text-muted-foreground">{p.prof}</p>
                <p className="mt-2 text-xs font-medium">{p.quando}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}