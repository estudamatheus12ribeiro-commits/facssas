import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Star, BookOpen, Users, Mail, Award } from "lucide-react";
import { useProfessor } from "@/lib/api/queries";
import { LoadingState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/professores/$slug")({
  head: () => ({ meta: [{ title: `Professor — FACULTECH` }] }),
  component: ProfessorDetalhe,
});

function ProfessorDetalhe() {
  const { slug } = Route.useParams();
  const { data: p, isLoading, isError, error } = useProfessor(slug);

  if (isLoading) return <div className="p-10"><LoadingState label="Carregando professor…" /></div>;
  if (isError) return <div className="p-10"><PageHeader backTo="/professores" backLabel="Voltar para professores" title="Erro" /><div className="mt-6"><ErrorState message={(error as Error)?.message} /></div></div>;
  if (!p) return <div className="p-10"><PageHeader backTo="/professores" backLabel="Voltar para professores" title="Professor não encontrado" /></div>;

  const iniciais = p.nome.split(" ").slice(-2).map((s) => s[0]).join("");
  return (
    <>
      <PageHeader
        backTo="/professores"
        backLabel="Voltar para professores"
        eyebrow={`${p.titulacao ?? ""} · ${p.area ?? ""}`}
        title={p.nome}
        description="Perfil do docente, disciplinas atribuídas e avaliação institucional."
        actions={
          <>
            <Button variant="outline" size="sm"><Mail className="h-4 w-4" /> Contatar</Button>
            <Button variant="hero" size="sm"><BookOpen className="h-4 w-4" /> Atribuir disciplina</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Disciplinas ativas" value={String(p.disciplinas)} icon={BookOpen} accent="text-blue-600" />
          <StatCard label="Avaliação" value={`${p.nota ?? "—"}/5`} icon={Star} accent="text-amber-600" />
          <StatCard label="Turmas" value="11" icon={Users} accent="text-violet-600" />
          <StatCard label="Titulação" value={p.titulacao ?? "—"} icon={Award} accent="text-emerald-600" />
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          <article className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-lg font-bold text-primary">{iniciais}</div>
              <div>
                <p className="font-semibold">{p.nome}</p>
                <p className="text-xs text-muted-foreground">{p.email}</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Atua na área de <strong className="text-foreground">{p.area}</strong> com foco em pesquisa aplicada e formação continuada de docentes.
            </p>
          </article>

          <article className="rounded-2xl border border-border bg-card p-6 shadow-sm lg:col-span-2">
            <h2 className="font-display text-lg font-semibold">Disciplinas atribuídas</h2>
            <div className="mt-4 space-y-3">
              {["Didática do Ensino Superior", "Avaliação da Aprendizagem", "Tecnologias Educacionais", "Metodologia da Pesquisa"].slice(0, p.disciplinas).map((d) => (
                <div key={d} className="flex items-center justify-between rounded-xl border border-border bg-secondary/30 p-3 text-sm">
                  <span className="font-medium">{d}</span>
                  <span className="text-xs text-muted-foreground">3 turmas · 84 alunos</span>
                </div>
              ))}
            </div>
          </article>
        </div>
      </div>
    </>
  );
}
