import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Sparkles, BookOpen, FileText, Bot, Zap } from "lucide-react";

export const Route = createFileRoute("/_authenticated/ia")({
  head: () => ({ meta: [{ title: "IA Educacional — FACULTECH" }] }),
  component: IA,
});

const skills = [
  { titulo: "Gerar plano de ensino", desc: "Crie planos alinhados às DCN a partir de uma ementa.", icon: BookOpen, tag: "Docente" },
  { titulo: "Banco de questões", desc: "Provas, simulados e atividades por nível de dificuldade.", icon: FileText, tag: "Avaliação" },
  { titulo: "Tutor 24/7 do aluno", desc: "Tira-dúvidas contextual no AVA, com referências.", icon: Bot, tag: "Aluno" },
  { titulo: "Correção automática", desc: "Discursivas e redações com rubrica configurável.", icon: Zap, tag: "Avaliação" },
  { titulo: "Aproveitamento curricular", desc: "Analisa históricos e sugere equivalências.", icon: Sparkles, tag: "Secretaria" },
  { titulo: "Resumo de aulas", desc: "Transforma vídeo em transcrição + mapa mental.", icon: BookOpen, tag: "Aluno" },
];

function IA() {
  return (
    <>
      <PageHeader
        eyebrow="Inteligência"
        title="IA Educacional nativa"
        description="Assistentes especializados para docentes, secretaria e alunos. Modelos auditáveis e seguros."
        actions={<Button variant="hero" size="sm"><Sparkles className="h-4 w-4" /> Abrir copiloto</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Execuções (mês)" value="124k" icon={Zap} accent="text-violet-600" />
          <StatCard label="Planos gerados" value="1.412" icon={BookOpen} accent="text-blue-600" />
          <StatCard label="Questões criadas" value="48.2k" icon={FileText} accent="text-emerald-600" />
          <StatCard label="Satisfação" value="4,8/5" icon={Sparkles} accent="text-amber-600" />
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {skills.map((s) => (
            <article key={s.titulo} className="group rounded-2xl border border-border bg-card p-6 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-card)]">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground">
                <s.icon className="h-5 w-5" />
              </div>
              <p className="mt-4 text-[10px] font-semibold uppercase tracking-wider text-primary">{s.tag}</p>
              <h3 className="mt-1 font-display text-lg font-semibold">{s.titulo}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
              <Button variant="outline" size="sm" className="mt-4 w-full">Executar</Button>
            </article>
          ))}
        </section>
      </div>
    </>
  );
}