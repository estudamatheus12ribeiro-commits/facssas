import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Clock, Layers, Plus } from "lucide-react";
import { useCurso } from "@/lib/api/queries";
import { LoadingState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/cursos/$slug")({
  head: () => ({ meta: [{ title: "Curso — FACULTECH" }] }),
  component: CursoDetalhe,
});

const matriz = [
  { mod: "Módulo I — Fundamentos", disciplinas: ["Introdução à área", "Metodologia da pesquisa", "História e contexto"] },
  { mod: "Módulo II — Núcleo aplicado", disciplinas: ["Prática supervisionada", "Estudos de caso", "Laboratório"] },
  { mod: "Módulo III — Aprofundamento", disciplinas: ["Tendências contemporâneas", "Avaliação de impacto", "TCC / Projeto integrador"] },
];

function CursoDetalhe() {
  const { slug } = Route.useParams();
  const { data: c, isLoading, isError, error } = useCurso(slug);

  if (isLoading) return <div className="p-10"><LoadingState label="Carregando curso…" /></div>;
  if (isError) return <div className="p-10"><PageHeader backTo="/cursos" backLabel="Voltar para cursos" title="Erro" /><div className="mt-6"><ErrorState message={(error as Error)?.message} /></div></div>;
  if (!c) return <div className="p-10"><PageHeader backTo="/cursos" backLabel="Voltar para cursos" title="Curso não encontrado" /></div>;

  return (
    <>
      <PageHeader
        backTo="/cursos"
        backLabel="Voltar para cursos"
        eyebrow={c.modalidade ?? undefined}
        title={c.titulo}
        description={`Coordenação: ${c.coordenador ?? "—"} · Duração ${c.duracao ?? "—"}`}
        actions={
          <>
            <Button variant="outline" size="sm">Matriz curricular</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nova turma</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Alunos matriculados" value={(c.alunos ?? 0).toLocaleString("pt-BR")} icon={Users} accent="text-blue-600" />
          <StatCard label="Disciplinas" value={String(c.disciplinas)} icon={Layers} accent="text-violet-600" />
          <StatCard label="Carga horária" value={c.carga ?? "—"} icon={Clock} accent="text-amber-600" />
          <StatCard label="Status" value={c.status} icon={BookOpen} accent="text-emerald-600" />
        </section>

        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h2 className="font-display text-lg font-semibold">Matriz curricular</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {matriz.map((m) => (
              <div key={m.mod} className="rounded-xl border border-border bg-secondary/30 p-4">
                <p className="font-semibold">{m.mod}</p>
                <ul className="mt-3 space-y-1.5 text-sm text-muted-foreground">
                  {m.disciplinas.map((d) => (
                    <li key={d} className="flex items-start gap-2">
                      <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /> {d}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
