import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Users, GraduationCap, Wallet, TrendingUp, Briefcase, Building2,
  CheckCircle2, AlertTriangle, ArrowUpRight, Download, Plus,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard Executivo — FACULTECH" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = useAuth();
  const name = (user?.user_metadata?.full_name as string) || user?.email?.split("@")[0] || "Gestor";

  return (
    <>
      <PageHeader
        eyebrow="Visão geral"
        title={`Bem-vindo, ${name}`}
        description="Painel executivo consolidado: comercial, acadêmico, financeiro e operacional."
        actions={
          <>
            <Button variant="outline" size="sm"><Download className="h-4 w-4" /> Exportar</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nova matrícula</Button>
          </>
        }
      />

      <div className="space-y-8 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Alunos ativos" value="12.847" hint="+8,2% vs. mês anterior" icon={Users} accent="text-blue-600" />
          <StatCard label="Receita do mês" value="R$ 4,82M" hint="+12,1% MoM" icon={Wallet} accent="text-emerald-600" />
          <StatCard label="Leads no funil" value="3.412" hint="412 quentes" icon={Briefcase} accent="text-violet-600" />
          <StatCard label="Polos ativos" value="47" hint="6 em onboarding" icon={Building2} accent="text-amber-600" />
        </section>

        <section className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="font-display text-lg font-semibold">Matrículas e receita — últimos 6 meses</h2>
                <p className="text-xs text-muted-foreground">Comparativo mensal consolidado</p>
              </div>
              <Button variant="ghost" size="sm">Detalhar <ArrowUpRight className="h-3.5 w-3.5" /></Button>
            </div>
            <div className="flex h-56 items-end gap-3">
              {[42, 55, 48, 67, 73, 88].map((v, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-2">
                  <div className="flex w-full flex-col items-center gap-1">
                    <div className="w-full rounded-t bg-[image:var(--gradient-primary)]" style={{ height: `${v * 1.8}px` }} />
                    <div className="w-full rounded-b bg-primary/20" style={{ height: `${v * 0.6}px` }} />
                  </div>
                  <span className="text-xs text-muted-foreground">{["Jan","Fev","Mar","Abr","Mai","Jun"][i]}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center gap-6 text-xs">
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded bg-primary" /> Receita</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded bg-primary/30" /> Matrículas</span>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="font-display text-lg font-semibold">Conversão do funil</h2>
            <p className="text-xs text-muted-foreground">Pipeline comercial</p>
            <div className="mt-5 space-y-4">
              {[
                { l: "Leads", v: 3412, p: 100 },
                { l: "Qualificados", v: 1847, p: 54 },
                { l: "Propostas", v: 892, p: 26 },
                { l: "Matriculados", v: 421, p: 12 },
              ].map((s) => (
                <div key={s.l}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-medium">{s.l}</span>
                    <span className="text-muted-foreground">{s.v.toLocaleString("pt-BR")} · {s.p}%</span>
                  </div>
                  <Progress value={s.p} className="h-1.5" />
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="mb-4 font-display text-lg font-semibold">Cursos com melhor desempenho</h2>
            <div className="space-y-3">
              {[
                { c: "MBA Gestão Educacional", a: 1248, t: 91 },
                { c: "Pedagogia EAD", a: 2104, t: 87 },
                { c: "Pós em Psicopedagogia", a: 832, t: 84 },
                { c: "Engenharia de Software", a: 1567, t: 79 },
              ].map((c) => (
                <div key={c.c} className="flex items-center justify-between rounded-lg border border-border/60 bg-secondary/30 p-3">
                  <div>
                    <p className="text-sm font-medium">{c.c}</p>
                    <p className="text-xs text-muted-foreground">{c.a.toLocaleString("pt-BR")} alunos</p>
                  </div>
                  <div className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-xs font-medium text-emerald-700">
                    <TrendingUp className="h-3 w-3" /> {c.t}% conclusão
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="mb-4 font-display text-lg font-semibold">Alertas operacionais</h2>
            <ul className="space-y-3">
              {[
                { t: "12 boletos vencendo em 48h", d: "Acionar régua de cobrança", icon: AlertTriangle, c: "text-amber-600" },
                { t: "3 polos sem renovação de contrato", d: "Vencimento em junho", icon: AlertTriangle, c: "text-destructive" },
                { t: "Certificações pendentes: 87", d: "Aguardando assinatura digital", icon: CheckCircle2, c: "text-primary" },
                { t: "Novo plano de ensino gerado por IA", d: "MBA Gestão · Disciplina 04", icon: GraduationCap, c: "text-violet-600" },
              ].map((a) => (
                <li key={a.t} className="flex items-start gap-3 rounded-lg border border-border/60 p-3">
                  <a.icon className={`mt-0.5 h-4 w-4 ${a.c}`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{a.t}</p>
                    <p className="text-xs text-muted-foreground">{a.d}</p>
                  </div>
                  <Button variant="ghost" size="sm">Ver</Button>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </>
  );
}