import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Users, TrendingUp, Receipt, MapPin, Calendar, User } from "lucide-react";
import { usePolo } from "@/lib/api/queries";
import { LoadingState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/polos/$slug")({
  head: () => ({ meta: [{ title: "Polo — FACULTECH" }] }),
  component: PoloDetalhe,
});

function PoloDetalhe() {
  const { slug } = Route.useParams();
  const { data: p, isLoading, isError, error } = usePolo(slug);

  if (isLoading) return <div className="p-10"><LoadingState label="Carregando polo…" /></div>;
  if (isError) return <div className="p-10"><PageHeader backTo="/polos" backLabel="Voltar para polos" title="Erro" /><div className="mt-6"><ErrorState message={(error as Error)?.message} /></div></div>;
  if (!p) return <div className="p-10"><PageHeader backTo="/polos" backLabel="Voltar para polos" title="Polo não encontrado" /></div>;

  return (
    <>
      <PageHeader
        backTo="/polos"
        backLabel="Voltar para polos"
        eyebrow="Polo EAD"
        title={p.nome}
        description={`${p.cidade} · em operação desde ${p.abertura}`}
        actions={
          <>
            <span className={`rounded-full px-3 py-1 text-xs font-medium ${p.status === "Ativo" ? "bg-emerald-500/10 text-emerald-700" : "bg-amber-500/10 text-amber-700"}`}>{p.status}</span>
            <Button variant="hero" size="sm">Editar polo</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Alunos ativos" value={(p.alunos ?? 0).toLocaleString("pt-BR")} icon={Users} accent="text-blue-600" />
          <StatCard label="Receita mensal" value={p.receita ?? "—"} icon={TrendingUp} accent="text-emerald-600" />
          <StatCard label="Comissão (mês)" value={p.comissao ?? "—"} icon={Receipt} accent="text-amber-600" />
          <StatCard label="Captação ativa" value="84 leads" icon={User} accent="text-violet-600" />
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          <article className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="font-display text-lg font-semibold">Informações</h2>
            <dl className="mt-4 space-y-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-3"><MapPin className="h-4 w-4" /><span>{p.cidade}</span></div>
              <div className="flex items-center gap-3"><User className="h-4 w-4" /><span>Responsável: {p.responsavel}</span></div>
              <div className="flex items-center gap-3"><Calendar className="h-4 w-4" /><span>Abertura em {p.abertura}</span></div>
            </dl>
          </article>

          <article className="rounded-2xl border border-border bg-card p-6 shadow-sm lg:col-span-2">
            <h2 className="font-display text-lg font-semibold">Desempenho últimos 6 meses</h2>
            <div className="mt-4 flex h-44 items-end gap-3">
              {[42, 58, 51, 73, 81, 92].map((v, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-1">
                  <div className="w-full rounded-t-md bg-[image:var(--gradient-primary)]" style={{ height: `${v}%` }} />
                  <span className="text-[10px] text-muted-foreground">M{i + 1}</span>
                </div>
              ))}
            </div>
          </article>
        </div>
      </div>
    </>
  );
}
