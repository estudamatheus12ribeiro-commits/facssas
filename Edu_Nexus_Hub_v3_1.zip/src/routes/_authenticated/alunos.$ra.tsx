import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin, GraduationCap, Calendar, FileText, CreditCard, BookOpen } from "lucide-react";
import { useAluno } from "@/lib/api/queries";
import { LoadingState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/alunos/$ra")({
  head: ({ params }) => ({ meta: [{ title: `Aluno ${params.ra} — FACULTECH` }] }),
  component: AlunoDetalhe,
});

const statusColor: Record<string, string> = {
  Ativo: "bg-emerald-500/10 text-emerald-700",
  Inadimplente: "bg-amber-500/10 text-amber-700",
  Trancado: "bg-slate-500/10 text-slate-700",
};

function AlunoDetalhe() {
  const { ra } = Route.useParams();
  const { data: a, isLoading, isError, error } = useAluno(ra);

  if (isLoading) return <div className="p-10"><LoadingState label="Carregando aluno…" /></div>;
  if (isError) return <div className="p-10"><PageHeader backTo="/alunos" backLabel="Voltar para alunos" title="Erro" /><div className="mt-6"><ErrorState message={(error as Error)?.message} /></div></div>;
  if (!a) {
    return (
      <div className="p-10">
        <PageHeader backTo="/alunos" backLabel="Voltar para alunos" title="Aluno não encontrado" description={`Nenhum aluno com RA ${ra}.`} />
      </div>
    );
  }

  return (
    <>
      <PageHeader
        backTo="/alunos"
        backLabel="Voltar para alunos"
        eyebrow={`RA ${a.ra}`}
        title={a.nome}
        description={`${a.curso ?? "—"} · ${a.polo ?? "—"}`}
        actions={
          <>
            <span className={`rounded-full px-3 py-1 text-xs font-medium ${statusColor[a.status] ?? "bg-secondary text-foreground"}`}>{a.status}</span>
            <Button variant="outline" size="sm"><Mail className="h-4 w-4" /> Mensagem</Button>
            <Button variant="hero" size="sm"><FileText className="h-4 w-4" /> Histórico</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Progresso do curso" value={`${a.progresso}%`} icon={GraduationCap} accent="text-blue-600" />
          <StatCard label="Disciplinas concluídas" value="12 / 18" icon={BookOpen} accent="text-violet-600" />
          <StatCard label="Frequência" value="94%" icon={Calendar} accent="text-emerald-600" />
          <StatCard label="Mensalidade" value="R$ 489" hint="em dia" icon={CreditCard} accent="text-amber-600" />
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          <article className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="font-display text-lg font-semibold">Dados pessoais</h2>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex items-center gap-3 text-muted-foreground"><Mail className="h-4 w-4" /><span>{a.email ?? "—"}</span></div>
              <div className="flex items-center gap-3 text-muted-foreground"><Phone className="h-4 w-4" /><span>{a.telefone ?? "—"}</span></div>
              <div className="flex items-center gap-3 text-muted-foreground"><MapPin className="h-4 w-4" /><span>{a.polo ?? "—"}</span></div>
              <div className="flex items-center gap-3 text-muted-foreground"><FileText className="h-4 w-4" /><span>CPF {a.cpf ?? "—"}</span></div>
              <div className="flex items-center gap-3 text-muted-foreground"><Calendar className="h-4 w-4" /><span>Ingresso {a.ingresso ?? "—"}</span></div>
            </dl>
          </article>

          <article className="rounded-2xl border border-border bg-card p-6 shadow-sm lg:col-span-2">
            <h2 className="font-display text-lg font-semibold">Progresso acadêmico</h2>
            <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-secondary">
              <div className="h-full rounded-full bg-[image:var(--gradient-primary)]" style={{ width: `${a.progresso}%` }} />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{a.progresso}% do curso concluído</p>

            <div className="mt-6 space-y-3">
              {[
                { d: "Didática do Ensino Superior", n: "9,4", s: "Aprovado" },
                { d: "Avaliação da Aprendizagem", n: "8,7", s: "Aprovado" },
                { d: "Psicologia da Educação", n: "—", s: "Em curso" },
                { d: "Tecnologias Educacionais", n: "—", s: "Em curso" },
              ].map((d) => (
                <div key={d.d} className="flex items-center justify-between rounded-xl border border-border bg-secondary/30 p-3 text-sm">
                  <span className="font-medium">{d.d}</span>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-muted-foreground">{d.n}</span>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${d.s === "Aprovado" ? "bg-emerald-500/10 text-emerald-700" : "bg-primary/10 text-primary"}`}>{d.s}</span>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </div>
      </div>
    </>
  );
}
