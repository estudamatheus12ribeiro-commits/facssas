import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Award, FileSignature, ShieldCheck, Download, Plus } from "lucide-react";

export const Route = createFileRoute("/_authenticated/certificados")({
  head: () => ({ meta: [{ title: "Certificados — FACULTECH" }] }),
  component: Certificados,
});

const certs = [
  { proto: "CERT-2026-08412", aluno: "Camila Duarte", curso: "Pós Psicopedagogia", emissao: "28/05/2026", status: "Emitido", hash: "0xa8f3…b21c" },
  { proto: "CERT-2026-08413", aluno: "Bruno Carvalho", curso: "MBA Gestão Educacional", emissao: "29/05/2026", status: "Aguardando assinatura", hash: "—" },
  { proto: "CERT-2026-08414", aluno: "Eduarda Martins", curso: "Segunda Licenciatura", emissao: "30/05/2026", status: "Emitido", hash: "0x71be…f290" },
  { proto: "CERT-2026-08415", aluno: "Henrique Sales", curso: "Formação Pedagógica", emissao: "30/05/2026", status: "Processando", hash: "—" },
  { proto: "CERT-2026-08416", aluno: "Gabriela Rocha", curso: "Tecnólogo em Marketing", emissao: "31/05/2026", status: "Emitido", hash: "0x3d9a…e012" },
];

const statusColor: Record<string, string> = {
  Emitido: "bg-emerald-500/10 text-emerald-700",
  "Aguardando assinatura": "bg-amber-500/10 text-amber-700",
  Processando: "bg-blue-500/10 text-blue-700",
};

function Certificados() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Certificação digital"
        description="Emissão automática, assinatura digital ICP-Brasil e validação via blockchain."
        actions={
          <>
            <Button variant="outline" size="sm"><ShieldCheck className="h-4 w-4" /> Validar</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Emitir certificado</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Emitidos no ano" value="8.412" icon={Award} accent="text-emerald-600" />
          <StatCard label="Aguardando assinatura" value="87" icon={FileSignature} accent="text-amber-600" />
          <StatCard label="Validados (blockchain)" value="100%" icon={ShieldCheck} accent="text-violet-600" />
          <StatCard label="Downloads (mês)" value="2.341" icon={Download} accent="text-blue-600" />
        </section>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr><th className="px-4 py-3">Protocolo</th><th className="px-4 py-3">Aluno</th><th className="px-4 py-3">Curso</th><th className="px-4 py-3">Emissão</th><th className="px-4 py-3">Hash</th><th className="px-4 py-3">Status</th><th></th></tr>
            </thead>
            <tbody>
              {certs.map((c) => (
                <tr key={c.proto} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-mono text-xs">{c.proto}</td>
                  <td className="px-4 py-3 font-medium">{c.aluno}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.curso}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.emissao}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{c.hash}</td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusColor[c.status]}`}>{c.status}</span></td>
                  <td className="px-4 py-3 text-right"><Button variant="ghost" size="sm">Abrir</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}