import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  FileQuestion,
  ListChecks,
  PenLine,
  Sparkles,
  Plus,
  Clock,
  Users,
  CheckCircle2,
  Shuffle,
  Shield,
  Eye,
  Copy,
  MoreHorizontal,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/provas")({
  head: () => ({ meta: [{ title: "Provas — FACULTECH" }] }),
  component: Provas,
});

const provas = [
  { id: "AV1-PED-2026", titulo: "AV1 — Didática do Ensino Superior", curso: "Pedagogia EAD", tipo: "Mista", questoes: 12, duracao: "90 min", tentativas: 1, status: "Publicada", aplicacoes: 248 },
  { id: "AV2-MBA-2026", titulo: "AV2 — Liderança Educacional", curso: "MBA Gestão Educacional", tipo: "Discursiva", questoes: 5, duracao: "120 min", tentativas: 1, status: "Publicada", aplicacoes: 156 },
  { id: "SIM-ENG-01", titulo: "Simulado — Estrutura de Dados", curso: "Engenharia de Software", tipo: "Objetiva", questoes: 30, duracao: "60 min", tentativas: 3, status: "Rascunho", aplicacoes: 0 },
  { id: "REC-PSI-01", titulo: "Recuperação — Teorias da Aprendizagem", curso: "Pós Psicopedagogia", tipo: "Mista", questoes: 10, duracao: "90 min", tentativas: 2, status: "Agendada", aplicacoes: 0 },
  { id: "AV1-EJA-01", titulo: "AV1 — Língua Portuguesa", curso: "EJA - Médio", tipo: "Objetiva", questoes: 20, duracao: "60 min", tentativas: 1, status: "Publicada", aplicacoes: 412 },
];

const banco = [
  { tema: "Didática", objetivas: 142, discursivas: 38, taxonomia: "Bloom: análise/aplicação" },
  { tema: "Gestão Escolar", objetivas: 98, discursivas: 24, taxonomia: "Bloom: avaliação" },
  { tema: "Estrutura de Dados", objetivas: 210, discursivas: 12, taxonomia: "Bloom: aplicação" },
  { tema: "Psicopedagogia", objetivas: 124, discursivas: 46, taxonomia: "Bloom: análise" },
];

const previewQuestao = {
  enunciado:
    "Segundo Vygotsky, a Zona de Desenvolvimento Proximal (ZDP) representa o intervalo entre:",
  alternativas: [
    "O que o aluno já sabe e o que ainda não é capaz de aprender.",
    "O que o aluno faz sozinho e o que consegue fazer com mediação.",
    "O conhecimento empírico e o conhecimento científico.",
    "A avaliação diagnóstica e a avaliação somativa.",
  ],
  correta: 1,
};

const statusBadge = (s: string) => {
  if (s === "Publicada") return "bg-emerald-100 text-emerald-700";
  if (s === "Agendada") return "bg-blue-100 text-blue-700";
  if (s === "Rascunho") return "bg-amber-100 text-amber-700";
  return "bg-secondary text-foreground";
};

function Provas() {
  return (
    <>
      <PageHeader
        eyebrow="Avaliações"
        title="Criação de provas"
        description="Monte avaliações objetivas, discursivas ou mistas. Banco de questões, embaralhamento e antifraude integrados."
        actions={
          <>
            <Button variant="outline" size="sm"><Sparkles className="h-4 w-4" /> Gerar com IA</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nova prova</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Provas ativas" value="48" icon={FileQuestion} accent="text-blue-600" />
          <StatCard label="Questões no banco" value="2.184" icon={ListChecks} accent="text-violet-600" />
          <StatCard label="Aplicações (mês)" value="3.241" icon={Users} accent="text-emerald-600" />
          <StatCard label="Correção automática" value="92%" icon={CheckCircle2} accent="text-amber-600" />
        </section>

        {/* Tipos de prova */}
        <section className="grid gap-4 lg:grid-cols-3">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50">
              <ListChecks className="h-5 w-5 text-blue-600" />
            </div>
            <h3 className="font-semibold">Prova objetiva</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Múltipla escolha, V/F e associação. Correção automática e nota imediata para o aluno.
            </p>
            <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
              <li>• Embaralhar questões e alternativas</li>
              <li>• Peso por questão e nota mínima</li>
              <li>• Estatísticas de acerto por item</li>
            </ul>
            <Button variant="outline" size="sm" className="mt-4 w-full"><Plus className="h-4 w-4" /> Criar objetiva</Button>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-violet-50">
              <PenLine className="h-5 w-5 text-violet-600" />
            </div>
            <h3 className="font-semibold">Prova discursiva</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Questões abertas com editor rich text, anexos do aluno e rubrica de correção por critério.
            </p>
            <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
              <li>• Rubrica com critérios ponderados</li>
              <li>• Pré-correção sugerida por IA</li>
              <li>• Feedback individual por aluno</li>
            </ul>
            <Button variant="outline" size="sm" className="mt-4 w-full"><Plus className="h-4 w-4" /> Criar discursiva</Button>
          </div>

          <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/5 to-primary/10 p-6 shadow-sm">
            <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold">Geração com IA</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Forneça o tema, nível e quantidade — a IA gera enunciados, gabarito e justificativa pedagógica.
            </p>
            <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
              <li>• Taxonomia de Bloom configurável</li>
              <li>• Alinhamento à ementa do curso</li>
              <li>• Revisão humana antes de publicar</li>
            </ul>
            <Button variant="hero" size="sm" className="mt-4 w-full"><Sparkles className="h-4 w-4" /> Gerar agora</Button>
          </div>
        </section>

        {/* Configurações de segurança / aplicação */}
        <section className="grid gap-4 rounded-2xl border border-border bg-card p-6 shadow-sm lg:grid-cols-4">
          <div className="flex items-start gap-3">
            <Shuffle className="mt-0.5 h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-semibold">Embaralhamento</p>
              <p className="text-xs text-muted-foreground">Ordem aleatória por aluno.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Clock className="mt-0.5 h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-semibold">Tempo cronometrado</p>
              <p className="text-xs text-muted-foreground">Envio automático ao expirar.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Shield className="mt-0.5 h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-semibold">Antifraude</p>
              <p className="text-xs text-muted-foreground">Bloqueio de abas e webcam.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Eye className="mt-0.5 h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-semibold">Gabarito pós-prova</p>
              <p className="text-xs text-muted-foreground">Liberação após nota final.</p>
            </div>
          </div>
        </section>

        {/* Preview de questão */}
        <section className="grid gap-6 lg:grid-cols-3">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">Pré-visualização</p>
                <h3 className="text-sm font-semibold">Questão 1 de 12 · Objetiva · 1,0 pt</h3>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm"><Copy className="h-4 w-4" /> Duplicar</Button>
                <Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button>
              </div>
            </div>
            <p className="text-sm">{previewQuestao.enunciado}</p>
            <ol className="mt-4 space-y-2">
              {previewQuestao.alternativas.map((alt, i) => (
                <li
                  key={i}
                  className={`flex items-start gap-3 rounded-lg border p-3 text-sm ${
                    i === previewQuestao.correta
                      ? "border-emerald-200 bg-emerald-50"
                      : "border-border bg-background"
                  }`}
                >
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-border text-xs font-semibold">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="flex-1">{alt}</span>
                  {i === previewQuestao.correta && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2 py-0.5 text-xs font-medium text-white">
                      <CheckCircle2 className="h-3 w-3" /> Gabarito
                    </span>
                  )}
                </li>
              ))}
            </ol>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Banco de questões</p>
            <h3 className="text-sm font-semibold">Por tema</h3>
            <ul className="mt-4 space-y-3">
              {banco.map((b) => (
                <li key={b.tema} className="rounded-lg border border-border bg-background p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{b.tema}</p>
                    <span className="text-xs text-muted-foreground">{b.objetivas + b.discursivas} questões</span>
                  </div>
                  <div className="mt-1 flex gap-3 text-xs text-muted-foreground">
                    <span><ListChecks className="mr-1 inline h-3 w-3 text-blue-600" />{b.objetivas} obj.</span>
                    <span><PenLine className="mr-1 inline h-3 w-3 text-violet-600" />{b.discursivas} disc.</span>
                  </div>
                  <p className="mt-1 text-[11px] text-muted-foreground">{b.taxonomia}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Lista de provas */}
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <h3 className="text-sm font-semibold">Provas cadastradas</h3>
            <Button variant="ghost" size="sm">Ver todas</Button>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Título</th>
                <th className="px-4 py-3">Curso</th>
                <th className="px-4 py-3">Tipo</th>
                <th className="px-4 py-3">Questões</th>
                <th className="px-4 py-3">Duração</th>
                <th className="px-4 py-3">Aplicações</th>
                <th className="px-4 py-3">Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {provas.map((p) => (
                <tr key={p.id} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-mono text-xs">{p.id}</td>
                  <td className="px-4 py-3 font-medium">{p.titulo}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.curso}</td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">{p.tipo}</span>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{p.questoes}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.duracao}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.aplicacoes}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusBadge(p.status)}`}>{p.status}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="sm">Editar</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}