import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { UserCog, Plus, Star, BookOpen } from "lucide-react";
import { useProfessores } from "@/lib/api/queries";
import { LoadingState, EmptyState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/professores")({
  head: () => ({ meta: [{ title: "Professores — FACULTECH" }] }),
  component: Professores,
});

function Professores() {
  const { data: profs, isLoading, isError, error } = useProfessores();

  const total = profs?.length ?? 0;
  const doutores = profs?.filter((p) => p.titulacao === "Doutora" || p.titulacao === "Doutor").length ?? 0;
  const disciplinas = profs?.reduce((s, p) => s + (p.disciplinas ?? 0), 0) ?? 0;
  const notas = profs?.filter((p) => p.nota != null) ?? [];
  const media = notas.length ? (notas.reduce((s, p) => s + Number(p.nota), 0) / notas.length).toFixed(1).replace(".", ",") : "—";

  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Corpo docente"
        description="Cadastro, alocação em disciplinas, avaliação e folha de pagamento de professores."
        actions={<Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Novo professor</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Professores ativos" value={total.toLocaleString("pt-BR")} icon={UserCog} accent="text-blue-600" />
          <StatCard label="Doutores" value={doutores.toLocaleString("pt-BR")} icon={Star} accent="text-violet-600" />
          <StatCard label="Disciplinas ativas" value={disciplinas.toLocaleString("pt-BR")} icon={BookOpen} accent="text-amber-600" />
          <StatCard label="Avaliação média" value={`${media}/5`} icon={Star} accent="text-emerald-600" />
        </section>

        {isLoading && <LoadingState label="Carregando professores…" />}
        {isError && <ErrorState message={(error as Error)?.message} />}
        {!isLoading && !isError && total === 0 && (
          <EmptyState title="Nenhum professor cadastrado" description="Rode a migration de seed no Supabase ou cadastre o primeiro docente." />
        )}

        {!isLoading && !isError && total > 0 && (
          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {profs!.map((p) => (
              <div key={p.id} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">{p.nome.split(" ").slice(-2).map((s) => s[0]).join("")}</div>
                  <div>
                    <p className="font-semibold">{p.nome}</p>
                    <p className="text-xs text-muted-foreground">{p.titulacao} · {p.area}</p>
                  </div>
                </div>
                <div className="mt-4 flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{p.disciplinas} disciplinas</span>
                  <span className="flex items-center gap-1 font-medium"><Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />{p.nota}</span>
                </div>
                <Button variant="outline" size="sm" className="mt-4 w-full" asChild>
                  <Link to="/professores/$slug" params={{ slug: p.slug }}>Ver perfil</Link>
                </Button>
              </div>
            ))}
          </section>
        )}
      </div>
    </>
  );
}
