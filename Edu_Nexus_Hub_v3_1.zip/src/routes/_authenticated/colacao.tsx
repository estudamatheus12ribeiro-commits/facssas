import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  Award, CalendarDays, Users, MapPin, Plus, Download,
  CheckCircle2, Clock, FileSignature, Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/colacao")({
  head: () => ({ meta: [{ title: "Colação de grau — FACULTECH" }] }),
  component: Colacao,
});

const cerimonias = [
  { codigo: "COL-2026-1S", curso: "Pedagogia EAD + Segunda Licenciatura", data: "12/07/2026", local: "Teatro Cultura Artística — SP", concluintes: 184, status: "Confirmada" },
  { codigo: "COL-2026-MBA", curso: "MBA Gestão Educacional", data: "26/07/2026", local: "Auditório FACULTECH — BH", concluintes: 96, status: "Confirmada" },
  { codigo: "COL-2026-ENG", curso: "Engenharia de Software", data: "09/08/2026", local: "Centro de Eventos — Recife", concluintes: 142, status: "Em planejamento" },
  { codigo: "COL-2026-EJA", curso: "EJA - Médio (turma extraordinária)", data: "23/08/2026", local: "Polo Salvador", concluintes: 58, status: "Aguardando MEC" },
] as const;

const etapas = [
  { titulo: "Conferência acadêmica", desc: "Histórico, ENADE, TCC, estágio.", icon: CheckCircle2, status: "418 ok / 6 pendentes" },
  { titulo: "Quitação financeira", desc: "Mensalidades, taxas e biblioteca.", icon: FileSignature, status: "412 ok / 12 pendentes" },
  { titulo: "Documentação civil", desc: "RG, CPF, certidão de nascimento.", icon: Award, status: "420 ok / 4 pendentes" },
  { titulo: "Convite & RSVP", desc: "Lista nominal, acompanhantes, traje.", icon: Users, status: "374 confirmados" },
] as const;

const badge = (s: string) => {
  const t = s.toLowerCase();
  if (t.includes("confirm")) return "bg-emerald-100 text-emerald-700";
  if (t.includes("aguard") || t.includes("plan")) return "bg-amber-100 text-amber-700";
  return "bg-blue-100 text-blue-700";
};

function Colacao() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Colação de grau & cerimônias"
        description="Conferência de requisitos, agenda de cerimônias, ata oficial e emissão de diplomas pós-colação."
        actions={
          <>
            <Button variant="outline" size="sm"><Download className="h-4 w-4" /> Ata oficial</Button>
            <Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Nova cerimônia</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Concluintes 2026.1" value="480" icon={Users} accent="text-blue-600" />
          <StatCard label="Cerimônias agendadas" value="4" icon={CalendarDays} accent="text-violet-600" />
          <StatCard label="Requisitos OK" value="86%" icon={CheckCircle2} accent="text-emerald-600" />
          <StatCard label="Pendências críticas" value="22" icon={Clock} accent="text-amber-600" />
        </section>

        <section className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold">Checklist de elegibilidade</h2>
              <p className="text-xs text-muted-foreground">Pré-requisitos validados automaticamente antes da assinatura da ata.</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
              <Sparkles className="h-3.5 w-3.5" /> Validado por IA
            </span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {etapas.map((e) => (
              <div key={e.titulo} className="rounded-xl border border-border bg-background p-4">
                <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <e.icon className="h-4 w-4" />
                </div>
                <p className="text-sm font-semibold">{e.titulo}</p>
                <p className="mt-1 text-xs text-muted-foreground">{e.desc}</p>
                <p className="mt-3 text-xs font-medium text-foreground">{e.status}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card shadow-sm">
          <div className="border-b border-border px-6 py-4">
            <h2 className="text-sm font-semibold">Cerimônias do calendário</h2>
            <p className="text-xs text-muted-foreground">Datas oficiais, locais e quantitativo de concluintes.</p>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Código</th>
                <th className="px-4 py-3">Curso</th>
                <th className="px-4 py-3">Data</th>
                <th className="px-4 py-3">Local</th>
                <th className="px-4 py-3">Concluintes</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {cerimonias.map((c) => (
                <tr key={c.codigo} className="border-t border-border hover:bg-secondary/30">
                  <td className="px-4 py-3 font-mono text-xs">{c.codigo}</td>
                  <td className="px-4 py-3 font-medium">{c.curso}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.data}</td>
                  <td className="px-4 py-3"><span className="inline-flex items-center gap-1 text-muted-foreground"><MapPin className="h-3.5 w-3.5" /> {c.local}</span></td>
                  <td className="px-4 py-3 font-semibold">{c.concluintes}</td>
                  <td className="px-4 py-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${badge(c.status)}`}>{c.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </>
  );
}