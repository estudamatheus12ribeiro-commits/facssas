import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { CalendarCheck, Users, AlertTriangle, BookOpenCheck, Download, Save } from "lucide-react";

export const Route = createFileRoute("/_authenticated/diario")({
  head: () => ({ meta: [{ title: "Diário de Classe — FACULTECH" }] }),
  component: Diario,
});

const turma = [
  { ra: "2024001", nome: "Ana Beatriz Lima", p: [true, true, true, false, true], n1: 8.5, n2: 9.0 },
  { ra: "2024002", nome: "Bruno Carvalho", p: [true, false, true, true, true], n1: 7.0, n2: 6.5 },
  { ra: "2024003", nome: "Camila Duarte", p: [true, true, true, true, true], n1: 9.5, n2: 9.8 },
  { ra: "2024004", nome: "Diego Ferreira", p: [false, false, true, false, true], n1: 5.5, n2: 4.0 },
  { ra: "2024005", nome: "Eduarda Martins", p: [true, true, true, true, false], n1: 8.0, n2: 7.5 },
  { ra: "2024007", nome: "Gabriela Rocha", p: [true, true, true, true, true], n1: 9.0, n2: 9.2 },
];

const aulas = ["12/05", "14/05", "19/05", "21/05", "26/05"];

function Diario() {
  return (
    <>
      <PageHeader
        eyebrow="Acadêmico"
        title="Diário de Classe — Didática do Ensino Superior"
        description="Turma PED-2026.1 · Profª Dra. Helena Castro · 5 aulas registradas de 32"
        actions={
          <>
            <Button variant="outline" size="sm"><Download className="h-4 w-4" /> Exportar PDF</Button>
            <Button variant="hero" size="sm"><Save className="h-4 w-4" /> Salvar diário</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Alunos na turma" value="38" icon={Users} accent="text-blue-600" />
          <StatCard label="Frequência média" value="87%" icon={CalendarCheck} accent="text-emerald-600" />
          <StatCard label="Em risco de reprovação" value="4" icon={AlertTriangle} accent="text-amber-600" />
          <StatCard label="Plano de aula cumprido" value="68%" icon={BookOpenCheck} accent="text-violet-600" />
        </section>

        <div className="rounded-2xl border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border p-4">
            <div>
              <h2 className="font-display text-lg font-semibold">Chamada e notas</h2>
              <p className="text-xs text-muted-foreground">P = presença · N1/N2 = avaliações parciais</p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500" /> Presente
              <span className="ml-3 inline-flex h-2 w-2 rounded-full bg-rose-500" /> Falta
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/40 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">RA</th>
                  <th className="px-4 py-3 text-left">Aluno</th>
                  {aulas.map((a) => (
                    <th key={a} className="px-2 py-3 text-center">{a}</th>
                  ))}
                  <th className="px-3 py-3 text-center">% Freq.</th>
                  <th className="px-3 py-3 text-center">N1</th>
                  <th className="px-3 py-3 text-center">N2</th>
                  <th className="px-3 py-3 text-center">Média</th>
                </tr>
              </thead>
              <tbody>
                {turma.map((a) => {
                  const freq = Math.round((a.p.filter(Boolean).length / a.p.length) * 100);
                  const media = ((a.n1 + a.n2) / 2).toFixed(1);
                  const aprovado = Number(media) >= 7 && freq >= 75;
                  return (
                    <tr key={a.ra} className="border-t border-border hover:bg-secondary/30">
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{a.ra}</td>
                      <td className="px-4 py-3 font-medium">{a.nome}</td>
                      {a.p.map((ok, i) => (
                        <td key={i} className="px-2 py-3 text-center">
                          <span className={`inline-block h-3 w-3 rounded-full ${ok ? "bg-emerald-500" : "bg-rose-500"}`} />
                        </td>
                      ))}
                      <td className={`px-3 py-3 text-center font-semibold ${freq < 75 ? "text-rose-600" : "text-foreground"}`}>{freq}%</td>
                      <td className="px-3 py-3 text-center">{a.n1.toFixed(1)}</td>
                      <td className="px-3 py-3 text-center">{a.n2.toFixed(1)}</td>
                      <td className={`px-3 py-3 text-center font-semibold ${aprovado ? "text-emerald-600" : "text-rose-600"}`}>{media}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h3 className="font-display text-lg font-semibold">Plano de aula — 28/05/2026</h3>
            <p className="mt-1 text-sm text-muted-foreground">Tema: Avaliação formativa e somativa no ensino superior</p>
            <ul className="mt-4 space-y-2 text-sm">
              <li className="flex gap-2"><span className="text-primary">•</span> Discussão do texto base (Luckesi, 2011)</li>
              <li className="flex gap-2"><span className="text-primary">•</span> Atividade em grupo: elaboração de rubrica</li>
              <li className="flex gap-2"><span className="text-primary">•</span> Apresentação dos resultados e fechamento</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-6">
            <div className="flex items-center gap-2 text-amber-700">
              <AlertTriangle className="h-4 w-4" />
              <p className="text-sm font-semibold">Alertas pedagógicos automáticos</p>
            </div>
            <ul className="mt-3 space-y-2 text-sm text-foreground">
              <li>• <b>Diego Ferreira</b> — 40% de faltas e média abaixo de 5,0. Sugestão: contato da tutoria.</li>
              <li>• <b>Bruno Carvalho</b> — queda de rendimento entre N1 e N2 (−0,5). Indicar monitoria.</li>
              <li>• 3 alunos não acessaram o AVA nos últimos 7 dias.</li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}