import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Building2, MapPin, Users, TrendingUp, Plus } from "lucide-react";
import { usePolos } from "@/lib/api/queries";
import { LoadingState, EmptyState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/polos")({
  head: () => ({ meta: [{ title: "Polos EAD — FACULTECH" }] }),
  component: Polos,
});

function Polos() {
  const { data: polos, isLoading, isError, error } = usePolos();

  const total = polos?.length ?? 0;
  const ativos = polos?.filter((p) => p.status === "Ativo").length ?? 0;
  const cidades = new Set(polos?.map((p) => p.cidade).filter(Boolean)).size;
  const alunos = polos?.reduce((s, p) => s + (p.alunos ?? 0), 0) ?? 0;

  return (
    <>
      <PageHeader
        eyebrow="Operação"
        title="Polos EAD e parceiros"
        description="Gestão de unidades, captação local, comissionamento e desempenho por região."
        actions={<Button variant="hero" size="sm"><Plus className="h-4 w-4" /> Novo polo</Button>}
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Polos ativos" value={ativos.toLocaleString("pt-BR")} icon={Building2} accent="text-blue-600" />
          <StatCard label="Cidades atendidas" value={cidades.toLocaleString("pt-BR")} icon={MapPin} accent="text-violet-600" />
          <StatCard label="Alunos em polos" value={alunos.toLocaleString("pt-BR")} icon={Users} accent="text-emerald-600" />
          <StatCard label="Total de polos" value={total.toLocaleString("pt-BR")} icon={TrendingUp} accent="text-amber-600" />
        </section>

        {isLoading && <LoadingState label="Carregando polos…" />}
        {isError && <ErrorState message={(error as Error)?.message} />}
        {!isLoading && !isError && total === 0 && (
          <EmptyState title="Nenhum polo cadastrado" description="Rode a migration de seed no Supabase ou cadastre o primeiro polo." />
        )}

        {!isLoading && !isError && total > 0 && (
          <section className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
            {polos!.map((p) => (
              <div key={p.id} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-display font-semibold">{p.nome}</h3>
                    <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" /> {p.cidade}
                    </p>
                  </div>
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${p.status === "Ativo" ? "bg-emerald-500/10 text-emerald-700" : "bg-amber-500/10 text-amber-700"}`}>{p.status}</span>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-secondary/50 p-2"><p className="text-[10px] uppercase text-muted-foreground">Alunos</p><p className="text-sm font-semibold">{(p.alunos ?? 0).toLocaleString("pt-BR")}</p></div>
                  <div className="rounded-lg bg-secondary/50 p-2"><p className="text-[10px] uppercase text-muted-foreground">Receita</p><p className="text-sm font-semibold">{p.receita}</p></div>
                  <div className="rounded-lg bg-secondary/50 p-2"><p className="text-[10px] uppercase text-muted-foreground">Comissão</p><p className="text-sm font-semibold">{p.comissao}</p></div>
                </div>
                <Button variant="outline" size="sm" className="mt-4 w-full" asChild>
                  <Link to="/polos/$slug" params={{ slug: p.slug }}>Abrir polo</Link>
                </Button>
              </div>
            ))}
          </section>
        )}
      </div>
    </>
  );
}
