import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { CheckCircle2, FileSignature, FileText, CreditCard, ClipboardList, User } from "lucide-react";
import { useMatricula } from "@/lib/api/queries";
import { LoadingState, ErrorState } from "@/components/DataStates";

export const Route = createFileRoute("/_authenticated/matriculas/$proto")({
  head: ({ params }) => ({ meta: [{ title: `${params.proto} — FACULTECH` }] }),
  component: MatriculaDetalhe,
});

const etapas = ["Documentos", "Contrato", "Pagamento", "Concluída"];

function MatriculaDetalhe() {
  const { proto } = Route.useParams();
  const { data: m, isLoading, isError, error } = useMatricula(proto);

  if (isLoading) return <div className="p-10"><LoadingState label="Carregando matrícula…" /></div>;
  if (isError) return <div className="p-10"><PageHeader backTo="/matriculas" backLabel="Voltar para matrículas" title="Erro" /><div className="mt-6"><ErrorState message={(error as Error)?.message} /></div></div>;
  if (!m) return <div className="p-10"><PageHeader backTo="/matriculas" backLabel="Voltar para matrículas" title="Protocolo não encontrado" /></div>;

  const idx = etapas.indexOf(m.etapa ?? "");
  return (
    <>
      <PageHeader
        backTo="/matriculas"
        backLabel="Voltar para matrículas"
        eyebrow={m.proto}
        title={m.aluno}
        description={`${m.curso ?? "—"} · solicitada em ${m.data ?? "—"}`}
        actions={
          <>
            <Button variant="outline" size="sm"><FileText className="h-4 w-4" /> Documentos</Button>
            <Button variant="hero" size="sm"><FileSignature className="h-4 w-4" /> Avançar etapa</Button>
          </>
        }
      />
      <div className="space-y-6 p-6 lg:p-10">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Etapa atual" value={m.etapa ?? "—"} icon={ClipboardList} accent="text-blue-600" />
          <StatCard label="Status" value={m.status ?? "—"} icon={CheckCircle2} accent="text-emerald-600" />
          <StatCard label="Valor do contrato" value={m.valor ?? "—"} hint={m.parcelas ?? undefined} icon={CreditCard} accent="text-amber-600" />
          <StatCard label="Consultor" value={m.responsavel ?? "—"} icon={User} accent="text-violet-600" />
        </section>

        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h2 className="font-display text-lg font-semibold">Linha do tempo</h2>
          <ol className="mt-6 grid gap-4 md:grid-cols-4">
            {etapas.map((e, i) => {
              const done = i < idx || m.status === "Matriculado";
              const current = i === idx && m.status !== "Matriculado";
              return (
                <li key={e} className={`rounded-xl border p-4 ${done ? "border-emerald-500/40 bg-emerald-500/5" : current ? "border-primary bg-primary/5" : "border-border bg-secondary/30"}`}>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Etapa {i + 1}</p>
                  <p className="mt-1 font-semibold">{e}</p>
                  <p className="mt-2 text-xs text-muted-foreground">{done ? "Concluída" : current ? "Em andamento" : "Pendente"}</p>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </>
  );
}
