export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          institution_name: string | null
          role: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          institution_name?: string | null
          role?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          institution_name?: string | null
          role?: string
          updated_at?: string
        }
        Relationships: []
      }
      alunos: {
        Row: {
          id: string
          ra: string
          nome: string
          curso: string | null
          polo: string | null
          status: string
          progresso: number
          email: string | null
          telefone: string | null
          ingresso: string | null
          cpf: string | null
          created_at: string
        }
        Insert: {
          id?: string
          ra: string
          nome: string
          curso?: string | null
          polo?: string | null
          status?: string
          progresso?: number
          email?: string | null
          telefone?: string | null
          ingresso?: string | null
          cpf?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          ra?: string
          nome?: string
          curso?: string | null
          polo?: string | null
          status?: string
          progresso?: number
          email?: string | null
          telefone?: string | null
          ingresso?: string | null
          cpf?: string | null
          created_at?: string
        }
        Relationships: []
      }
      cursos: {
        Row: {
          id: string
          slug: string
          titulo: string
          modalidade: string | null
          carga: string | null
          alunos: number
          disciplinas: number
          status: string
          duracao: string | null
          coordenador: string | null
          created_at: string
        }
        Insert: {
          id?: string
          slug: string
          titulo: string
          modalidade?: string | null
          carga?: string | null
          alunos?: number
          disciplinas?: number
          status?: string
          duracao?: string | null
          coordenador?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          slug?: string
          titulo?: string
          modalidade?: string | null
          carga?: string | null
          alunos?: number
          disciplinas?: number
          status?: string
          duracao?: string | null
          coordenador?: string | null
          created_at?: string
        }
        Relationships: []
      }
      matriculas: {
        Row: {
          id: string
          proto: string
          aluno: string
          curso: string | null
          data: string | null
          etapa: string | null
          status: string | null
          responsavel: string | null
          valor: string | null
          parcelas: string | null
          created_at: string
        }
        Insert: {
          id?: string
          proto: string
          aluno: string
          curso?: string | null
          data?: string | null
          etapa?: string | null
          status?: string | null
          responsavel?: string | null
          valor?: string | null
          parcelas?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          proto?: string
          aluno?: string
          curso?: string | null
          data?: string | null
          etapa?: string | null
          status?: string | null
          responsavel?: string | null
          valor?: string | null
          parcelas?: string | null
          created_at?: string
        }
        Relationships: []
      }
      polos: {
        Row: {
          id: string
          slug: string
          nome: string
          cidade: string | null
          alunos: number
          receita: string | null
          comissao: string | null
          status: string
          responsavel: string | null
          abertura: string | null
          created_at: string
        }
        Insert: {
          id?: string
          slug: string
          nome: string
          cidade?: string | null
          alunos?: number
          receita?: string | null
          comissao?: string | null
          status?: string
          responsavel?: string | null
          abertura?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          slug?: string
          nome?: string
          cidade?: string | null
          alunos?: number
          receita?: string | null
          comissao?: string | null
          status?: string
          responsavel?: string | null
          abertura?: string | null
          created_at?: string
        }
        Relationships: []
      }
      professores: {
        Row: {
          id: string
          slug: string
          nome: string
          titulacao: string | null
          area: string | null
          disciplinas: number
          nota: number | null
          email: string | null
          created_at: string
        }
        Insert: {
          id?: string
          slug: string
          nome: string
          titulacao?: string | null
          area?: string | null
          disciplinas?: number
          nota?: number | null
          email?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          slug?: string
          nome?: string
          titulacao?: string | null
          area?: string | null
          disciplinas?: number
          nota?: number | null
          email?: string | null
          created_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
