import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, GraduationCap, BookOpen, ClipboardList, Building2,
  Wallet, UserCog, Briefcase, LogOut, Library, Award, BarChart3, MessageSquare,
  Sparkles, Settings, Receipt, Video, FileQuestion, GitCompareArrows, CalendarCheck,
  Briefcase as BriefcaseIcon, Award as AwardIcon, Inbox,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/lib/auth-context";

type Item = { title: string; url: string; icon: typeof Users };

const groups: { label: string; items: Item[] }[] = [
  {
    label: "Visão geral",
    items: [
      { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
      { title: "Relatórios & BI", url: "/relatorios", icon: BarChart3 },
    ],
  },
  {
    label: "Comercial",
    items: [
      { title: "CRM — Leads", url: "/crm", icon: Briefcase },
      { title: "WhatsApp & Comunicação", url: "/comunicacao", icon: MessageSquare },
      { title: "Comissões", url: "/comissoes", icon: Receipt },
    ],
  },
  {
    label: "Acadêmico",
    items: [
      { title: "Alunos", url: "/alunos", icon: Users },
      { title: "Matrículas", url: "/matriculas", icon: ClipboardList },
      { title: "Cursos", url: "/cursos", icon: BookOpen },
      { title: "Professores", url: "/professores", icon: UserCog },
      { title: "AVA — Sala de aula", url: "/ava", icon: Video },
      { title: "Provas & Avaliações", url: "/provas", icon: FileQuestion },
      { title: "Aproveitamento", url: "/aproveitamento", icon: GitCompareArrows },
      { title: "Diário de Classe", url: "/diario", icon: CalendarCheck },
      { title: "Estágio & TCC", url: "/estagio", icon: BriefcaseIcon },
      { title: "Colação de Grau", url: "/colacao", icon: AwardIcon },
      { title: "Secretaria", url: "/secretaria", icon: Inbox },
      { title: "Biblioteca Digital", url: "/biblioteca", icon: Library },
      { title: "Certificados", url: "/certificados", icon: Award },
    ],
  },
  {
    label: "Operação",
    items: [
      { title: "Polos & EAD", url: "/polos", icon: Building2 },
      { title: "Financeiro", url: "/financeiro", icon: Wallet },
      { title: "IA Educacional", url: "/ia", icon: Sparkles },
      { title: "Configurações", url: "/configuracoes", icon: Settings },
    ],
  },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user, signOut } = useAuth();
  const name = (user?.user_metadata?.full_name as string) || user?.email?.split("@")[0] || "Usuário";

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <Link to="/" className="flex items-center px-2 py-1.5">
          {collapsed ? (
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--gradient-primary)]">
              <GraduationCap className="h-4 w-4 text-primary-foreground" />
            </div>
          ) : (
            <Logo />
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent>
        {groups.map((g) => (
          <SidebarGroup key={g.label}>
            {!collapsed && <SidebarGroupLabel>{g.label}</SidebarGroupLabel>}
            <SidebarGroupContent>
              <SidebarMenu>
                {g.items.map((item) => {
                  const active = pathname === item.url;
                  return (
                    <SidebarMenuItem key={item.url}>
                      <SidebarMenuButton asChild isActive={active} tooltip={item.title}>
                        <Link to={item.url}>
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <div className="flex items-center gap-2 p-2">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-semibold text-primary">
            {name.slice(0, 2).toUpperCase()}
          </div>
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{name}</p>
              <p className="truncate text-xs text-muted-foreground">{user?.email}</p>
            </div>
          )}
          {!collapsed && (
            <button
              onClick={signOut}
              className="rounded-md p-1.5 text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
              title="Sair"
            >
              <LogOut className="h-4 w-4" />
            </button>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}