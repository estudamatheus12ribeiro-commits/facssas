import { Loader2, Inbox, AlertTriangle } from "lucide-react";

export function LoadingState({ label = "Carregando…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 rounded-2xl border border-border bg-card p-12 text-sm text-muted-foreground shadow-sm">
      <Loader2 className="h-4 w-4 animate-spin text-primary" />
      {label}
    </div>
  );
}

export function EmptyState({
  title = "Nenhum registro encontrado",
  description,
}: {
  title?: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card p-12 text-center shadow-sm">
      <Inbox className="h-8 w-8 text-muted-foreground" />
      <p className="mt-3 font-medium">{title}</p>
      {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
    </div>
  );
}

export function ErrorState({ message }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-destructive/30 bg-destructive/5 p-12 text-center shadow-sm">
      <AlertTriangle className="h-8 w-8 text-destructive" />
      <p className="mt-3 font-medium text-destructive">Não foi possível carregar os dados</p>
      {message && <p className="mt-1 max-w-md text-sm text-muted-foreground">{message}</p>}
      <p className="mt-2 text-xs text-muted-foreground">
        Verifique se as tabelas foram criadas no Supabase (migration) e se você está autenticado.
      </p>
    </div>
  );
}
